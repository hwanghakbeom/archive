########################
# Gemini Enterprise (Discovery Engine) — inlined per subsidiary
# No hand-written module; no official module exists for this product.
########################

locals {
  # APIs required on every subsidiary host project. Compute API is added
  # separately in lb.tf because it's only needed when expose_via_lb = true.
  # Bootstrap note: cloudresourcemanager + serviceusage must be enabled
  # out-of-band on a fresh project before the very first `terraform apply`
  # — Terraform needs both to call Service Usage and Resource Manager.
  # After bootstrap, Terraform tracks cloudresourcemanager + serviceusage
  # in state and re-enabling is idempotent.
  gemini_apis = [
    "cloudresourcemanager.googleapis.com",
    "serviceusage.googleapis.com",
    "discoveryengine.googleapis.com",
    "storage.googleapis.com",
    "iam.googleapis.com",
    "aiplatform.googleapis.com",
    # Security controls (security.tf)
    "modelarmor.googleapis.com",
    "dlp.googleapis.com",
    "datacatalog.googleapis.com",
    "cloudkms.googleapis.com",
    # VPC-SC (vpc-sc.tf, gated by enable_vpc_sc but the API enable is harmless)
    "accesscontextmanager.googleapis.com",
  ]

  # subsidiary key / api -> { project, api }
  gemini_api_bindings = merge([
    for sub_key, sub in var.subsidiaries : {
      for api in local.gemini_apis :
      "${sub_key}/${api}" => {
        project = sub.project_id
        api     = api
      }
    }
  ]...)

}

resource "random_id" "gemini_suffix" {
  for_each    = var.subsidiaries
  byte_length = 3
}

resource "google_project_service" "gemini" {
  for_each = local.gemini_api_bindings

  project = each.value.project
  service = each.value.api

  disable_dependent_services = false
  disable_on_destroy         = false
}

# Per-subsidiary IAM bindings via the official terraform-google-modules/iam
# module — additive mode so existing bindings on the project aren't disturbed.
# Legacy role name `agentspaceUser` is used for end users (Agentspace was the
# prior product name for Gemini Enterprise).
module "iam_gemini" {
  source   = "terraform-google-modules/iam/google//modules/projects_iam"
  version  = "~> 8.0"
  for_each = var.subsidiaries

  projects = [each.value.project_id]
  mode     = "additive"

  bindings = {
    "roles/discoveryengine.admin"          = each.value.gemini_admin_members
    "roles/discoveryengine.agentspaceUser" = each.value.gemini_end_user_members
  }

  depends_on = [google_project_service.gemini]
}

resource "google_discovery_engine_data_store" "gemini" {
  for_each = var.subsidiaries

  project           = each.value.project_id
  location          = "global"
  data_store_id     = "ge-ds-${random_id.gemini_suffix[each.key].hex}"
  display_name      = "${each.value.company_name} data store"
  industry_vertical = "GENERIC"
  content_config    = "NO_CONTENT"
  solution_types    = ["SOLUTION_TYPE_SEARCH"]

  depends_on = [google_project_service.gemini]
}

resource "google_discovery_engine_search_engine" "gemini" {
  for_each = var.subsidiaries

  project           = each.value.project_id
  engine_id         = "ge-engine-${random_id.gemini_suffix[each.key].hex}"
  collection_id     = "default_collection"
  location          = google_discovery_engine_data_store.gemini[each.key].location
  display_name      = "${each.value.company_name} Gemini Enterprise"
  data_store_ids    = [google_discovery_engine_data_store.gemini[each.key].data_store_id]
  industry_vertical = "GENERIC"

  # Required for Gemini Enterprise. Without APP_TYPE_INTRANET the engine
  # is provisioned as a generic Search-for-Web app.
  app_type = "APP_TYPE_INTRANET"

  search_engine_config {}

  common_config {
    company_name = each.value.company_name
  }
}

resource "google_discovery_engine_acl_config" "gemini" {
  for_each = var.subsidiaries
  provider = google-beta

  project  = each.value.project_id
  location = "global"

  idp_config {
    idp_type = "GSUITE"
  }

  depends_on = [google_project_service.gemini]
}

resource "google_discovery_engine_widget_config" "gemini" {
  for_each = var.subsidiaries
  provider = google-beta

  project   = each.value.project_id
  location  = google_discovery_engine_search_engine.gemini[each.key].location
  engine_id = google_discovery_engine_search_engine.gemini[each.key].engine_id

  access_settings {
    enable_web_app = true
  }

  depends_on = [google_discovery_engine_acl_config.gemini]
}

# Assistant on the GE engine — this is where the Model Armor template
# (defined in security.tf) is actually wired to user prompts +
# assistant responses. Until this resource exists, the Model Armor
# template is just a policy artifact with no enforcement path.
resource "google_discovery_engine_assistant" "gemini" {
  for_each = var.subsidiaries

  project       = each.value.project_id
  location      = google_discovery_engine_search_engine.gemini[each.key].location
  collection_id = "default_collection"
  engine_id     = google_discovery_engine_search_engine.gemini[each.key].engine_id
  assistant_id  = "default_assistant"
  display_name  = "${each.value.company_name} Gemini Enterprise Assistant"

  generation_config {
    default_language = "ko"
  }

  customer_policy {
    model_armor_config {
      # Single template covers both directions for now: SDP + PI/Jailbreak +
      # RAI filters. The PI/Jailbreak filter is only meaningful on the
      # prompt path and the RAI filter is only meaningful on the response
      # path; the irrelevant filters become no-ops. Split into separate
      # `prompt_armor` and `response_armor` templates later if you want
      # tighter, direction-specific policies.
      user_prompt_template = google_model_armor_template.user_prompt_sanitize[each.key].id
      response_template    = google_model_armor_template.user_prompt_sanitize[each.key].id

      # FAIL_OPEN during initial rollout — if Model Armor returns an
      # error, the assistant request continues unsanitized rather than
      # failing the user. Flip to FAIL_CLOSED after the integration is
      # validated and the regional Model Armor SLO is trusted.
      failure_mode = "FAIL_OPEN"
    }
  }

  # Internal corporate app — no external grounding.
  web_grounding_type = "WEB_GROUNDING_TYPE_DISABLED"
}
