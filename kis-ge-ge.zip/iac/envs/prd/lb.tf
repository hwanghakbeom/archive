########################
# Optional — Custom domain LB per subsidiary
# Inlined because terraform-google-modules/lb-http doesn't support
# Internet FQDN NEG backends.
########################

locals {
  lb_subsidiaries = {
    for k, v in var.subsidiaries : k => v if try(v.expose_via_lb, false)
  }
}

# Enable Compute Engine API per opt-in subsidiary. The downstream LB
# resources depend on this implicitly via the depends_on edges below so
# the API is enabled before any compute.* resource is touched.
resource "google_project_service" "lb_compute" {
  for_each = local.lb_subsidiaries

  project = each.value.project_id
  service = "compute.googleapis.com"

  disable_dependent_services = false
  disable_on_destroy         = false
}

resource "google_compute_global_address" "lb" {
  for_each = local.lb_subsidiaries

  project    = each.value.project_id
  name       = "${each.key}-ge-ip"
  ip_version = "IPV4"

  depends_on = [google_project_service.lb_compute]
}

resource "google_compute_global_network_endpoint_group" "lb" {
  for_each = local.lb_subsidiaries

  project               = each.value.project_id
  name                  = "${each.key}-ge-neg"
  network_endpoint_type = "INTERNET_FQDN_PORT"
  default_port          = 443

  depends_on = [google_project_service.lb_compute]
}

resource "google_compute_global_network_endpoint" "lb" {
  for_each = local.lb_subsidiaries

  project                       = each.value.project_id
  global_network_endpoint_group = google_compute_global_network_endpoint_group.lb[each.key].name
  fqdn                          = var.gemini_widget_fqdn
  port                          = 443
}

resource "google_compute_backend_service" "lb" {
  for_each = local.lb_subsidiaries

  project               = each.value.project_id
  name                  = "${each.key}-ge-bes"
  protocol              = "HTTPS"
  port_name             = "https"
  timeout_sec           = 30
  enable_cdn            = false
  load_balancing_scheme = "EXTERNAL_MANAGED"

  # Belt-and-suspenders backup for url_map.urlRewrite.hostRewrite
  # (MZ GE_custom_domain_setting_guide.md §A-5 step 5).
  custom_request_headers = ["Host:${var.gemini_widget_fqdn}"]

  backend {
    group = google_compute_global_network_endpoint_group.lb[each.key].id
  }

  security_policy = try(each.value.cloud_armor_policy, null)
}

resource "google_compute_managed_ssl_certificate" "lb" {
  for_each = local.lb_subsidiaries

  project = each.value.project_id
  name    = "${each.key}-ge-cert"

  managed {
    domains = [each.value.custom_domain]
  }

  lifecycle {
    create_before_destroy = true
  }

  depends_on = [google_project_service.lb_compute]
}

resource "google_compute_url_map" "lb" {
  for_each = local.lb_subsidiaries

  project         = each.value.project_id
  name            = "${each.key}-ge-urlmap"
  default_service = google_compute_backend_service.lb[each.key].id

  host_rule {
    hosts        = [each.value.custom_domain]
    path_matcher = "ge-matcher"
  }

  path_matcher {
    name            = "ge-matcher"
    default_service = google_compute_backend_service.lb[each.key].id

    route_rules {
      priority = 1

      match_rules {
        prefix_match = try(each.value.gemini_app_path, "/test-app")
      }

      route_action {
        weighted_backend_services {
          backend_service = google_compute_backend_service.lb[each.key].id
          weight          = 100
        }
        url_rewrite {
          host_rewrite        = var.gemini_widget_fqdn
          path_prefix_rewrite = "/home/cid/${each.value.gemini_app_id}"
        }
      }
    }
  }
}

resource "google_compute_target_https_proxy" "lb" {
  for_each = local.lb_subsidiaries

  project          = each.value.project_id
  name             = "${each.key}-ge-proxy"
  url_map          = google_compute_url_map.lb[each.key].id
  ssl_certificates = [google_compute_managed_ssl_certificate.lb[each.key].id]
}

resource "google_compute_global_forwarding_rule" "lb" {
  for_each = local.lb_subsidiaries

  project               = each.value.project_id
  name                  = "${each.key}-ge-fwd"
  target                = google_compute_target_https_proxy.lb[each.key].id
  ip_address            = google_compute_global_address.lb[each.key].address
  port_range            = "443"
  load_balancing_scheme = "EXTERNAL_MANAGED"
}
