########################
# Project-level security controls — applied per subsidiary host project.
# Mirrors codebase/tf/SCENARIOS.md rows 3, 4, 9, 14, 18/25 partial, 44.
# Single-project topology: all security artifacts live in the subsidiary
# project (no separate security/kms/bq/gcs projects).
########################

data "google_project" "subsidiary" {
  for_each   = var.subsidiaries
  project_id = each.value.project_id
}

locals {
  # DLP built-in info-type detectors (KR_RRN, KR_DLN, KR_PASSPORT, …) and
  # Model Armor's SDP filter (which calls DLP under the hood) have regional
  # availability constraints — the Korean detectors only resolve in the
  # `us` multi-region. KMS keyring + Data Catalog stay in region_primary
  # (data-sovereignty-sensitive); the templates here are policy artifacts,
  # not customer data.
  security_templates_location = "us"
}

########################
# [Row 18/25 partial] KMS keyring + keys for future CMEK consumption.
# Key-level IAM is deferred until workloads (BQ datasets / GCS buckets)
# actually consume the keys — adds the encrypter/decrypter binding then.
########################
module "kms_data_keyring" {
  source   = "terraform-google-modules/kms/google"
  version  = "~> 4.0"
  for_each = var.subsidiaries

  project_id = each.value.project_id
  location   = var.region_primary
  keyring    = "kr-data-keyring"
  keys       = ["bq-cmek", "gcs-cmek"]

  depends_on = [google_project_service.gemini]
}

########################
# [Row 3 + Row 5] Model Armor template — user-prompt sanitization
# SDP + PI/Jailbreak + Responsible AI Safety filters in one template.
# Active enforcement still requires app-side integration (Model Armor
# API call from the GE app or agent runtime).
########################
resource "google_model_armor_template" "user_prompt_sanitize" {
  for_each = var.subsidiaries
  provider = google-beta

  project = each.value.project_id
  # Pinned to `us` because the embedded SDP filter calls DLP, which only
  # resolves KR_* built-in detectors in the us multi-region.
  location    = local.security_templates_location
  template_id = "ge-user-prompt-sanitize"

  filter_config {
    sdp_settings {
      basic_config {
        filter_enforcement = "ENABLED"
      }
    }
    pi_and_jailbreak_filter_settings {
      filter_enforcement = "ENABLED"
      confidence_level   = "LOW_AND_ABOVE"
    }
    rai_settings {
      rai_filters {
        filter_type      = "HARASSMENT"
        confidence_level = "HIGH"
      }
      rai_filters {
        filter_type      = "HATE_SPEECH"
        confidence_level = "HIGH"
      }
      rai_filters {
        filter_type      = "SEXUALLY_EXPLICIT"
        confidence_level = "HIGH"
      }
      rai_filters {
        filter_type      = "DANGEROUS"
        confidence_level = "HIGH"
      }
    }
  }

  depends_on = [google_project_service.gemini]
}

########################
# [Row 4] DLP de-identify template — used by app-side calls to mask
# detected PII before persisting / showing the response.
########################
resource "google_data_loss_prevention_deidentify_template" "ge_response_deid" {
  for_each = var.subsidiaries

  # `us` location — KR_RRN / KR_DLN / KR_PASSPORT detectors are not
  # available in asia-northeast3.
  parent       = "projects/${each.value.project_id}/locations/${local.security_templates_location}"
  display_name = "GE Response De-identification"

  deidentify_config {
    info_type_transformations {
      transformations {
        # Korean detectors use the KOREA_* prefix, not KR_*. Authoritative
        # list: GET https://dlp.googleapis.com/v2/locations/us/infoTypes
        info_types {
          name = "KOREA_RRN"
        }
        info_types {
          name = "KOREA_DRIVERS_LICENSE_NUMBER"
        }
        info_types {
          name = "KOREA_PASSPORT"
        }
        info_types {
          name = "CREDIT_CARD_NUMBER"
        }
        info_types {
          name = "EMAIL_ADDRESS"
        }
        primitive_transformation {
          character_mask_config {
            masking_character = "#"
            number_to_mask    = -1
          }
        }
      }
    }
  }

  depends_on = [google_project_service.gemini]
}

########################
# [Row 4] DLP inspect template — KR PII + Finance info types.
# Same template reused for any future BQ / GCS DLP Discovery configs
# (deferred until there's data worth scanning).
########################
resource "google_data_loss_prevention_inspect_template" "ge_inspect" {
  for_each = var.subsidiaries

  # `us` location — same KR detector availability constraint as the
  # de-identify template above.
  parent       = "projects/${each.value.project_id}/locations/${local.security_templates_location}"
  display_name = "KR PII + Finance Inspect"

  inspect_config {
    # Korean detectors use the KOREA_* prefix, not KR_*. Three extra KR
    # finance-relevant detectors added beyond the codebase's original
    # list: BRN (Business Registration Number), ARN (Alien Registration
    # Number), NHI_NUMBER (National Health Insurance) — all relevant for
    # KIS as a financial-services subsidiary.
    info_types {
      name = "KOREA_RRN"
    }
    info_types {
      name = "KOREA_DRIVERS_LICENSE_NUMBER"
    }
    info_types {
      name = "KOREA_PASSPORT"
    }
    info_types {
      name = "KOREA_BRN"
    }
    info_types {
      name = "KOREA_ARN"
    }
    info_types {
      name = "KOREA_NHI_NUMBER"
    }
    info_types {
      name = "CREDIT_CARD_NUMBER"
    }
    info_types {
      name = "IBAN_CODE"
    }
    info_types {
      name = "FINANCIAL_ACCOUNT_NUMBER"
    }
    info_types {
      name = "EMAIL_ADDRESS"
    }
    info_types {
      name = "PHONE_NUMBER"
    }
    min_likelihood = "POSSIBLE"
  }

  depends_on = [google_project_service.gemini]
}

########################
# [Row 14] Data Catalog PII taxonomy + Policy Tags
# Metadata only — concrete column-tag bindings happen at table-create
# time (BQ schemas). DLP Discovery config deferred (no BQ tables yet).
########################
resource "google_data_catalog_taxonomy" "pii_taxonomy" {
  for_each = var.subsidiaries

  project                = each.value.project_id
  region                 = var.region_primary
  display_name           = "PII_TAXONOMY"
  description            = "[Row 14] PII Policy Tag Taxonomy"
  activated_policy_types = ["FINE_GRAINED_ACCESS_CONTROL"]

  depends_on = [google_project_service.gemini]
}

resource "google_data_catalog_policy_tag" "pii_confidential" {
  for_each = var.subsidiaries

  taxonomy     = google_data_catalog_taxonomy.pii_taxonomy[each.key].id
  display_name = "confidential"
  description  = "민감 컬럼 (KR_RRN, CREDIT_CARD_NUMBER 등)"
}

resource "google_data_catalog_policy_tag" "pii_internal" {
  for_each = var.subsidiaries

  taxonomy          = google_data_catalog_taxonomy.pii_taxonomy[each.key].id
  display_name      = "internal"
  description       = "내부용 컬럼 (EMAIL_ADDRESS 등)"
  parent_policy_tag = google_data_catalog_policy_tag.pii_confidential[each.key].id
}

########################
# [Row 9] Discovery Engine quota override — abuse-rate ceiling
# The metric `conversational_search_read_requests` (unit
# `1/min/{project}`, GCP default 600/min) is the read path of the GE
# Assistant chat flow — every user query against the engine bumps it.
# Pinning an explicit override in IaC documents the intended ceiling
# and lets the value be tuned via var.discoveryengine_conversational_qpm
# without touching this file.
#
# Platform constraint: consumer overrides on this metric can only set
# values in the range 0–600 (i.e. can only TIGHTEN). Raising above 600
# requires a quota increase request to Google. Validation enforced in
# variables.tf.
#
# Discovered with:
#   gcloud alpha services quota list \
#     --service=discoveryengine.googleapis.com \
#     --consumer=projects/<project_id>
#
# The earlier codebase example used `discoveryengine.googleapis.com/queries`
# + `/min/project` — neither is a registered limit (`COMMON_QUOTA_LIMIT_NOT_FOUND`).
########################
resource "google_service_usage_consumer_quota_override" "discoveryengine_conversational_per_min" {
  for_each = var.subsidiaries
  provider = google-beta

  project        = data.google_project.subsidiary[each.key].number
  service        = "discoveryengine.googleapis.com"
  metric         = urlencode("discoveryengine.googleapis.com/conversational_search_read_requests")
  limit          = urlencode("/min/project")
  override_value = tostring(var.discoveryengine_conversational_qpm)
  force          = true

  depends_on = [google_project_service.gemini]
}

########################
# [Row 44] Vertex AI quota override — Agent infinite-inference ceiling
# Metric `reasoning_engine_service_query_requests` (unit
# `1/min/{project}/{region}`, GCP default 90/min) is the Vertex AI
# Reasoning Engine query path — every Agent Engine inference call
# against this project / region bumps it.
#
# Regional metric: the override carries a `dimensions = { region = ... }`
# argument scoped to var.region_primary. If an Agent workload later
# runs in a different region, duplicate this resource with that
# region in `dimensions`.
#
# Platform constraint (assumed, mirroring Row 9): consumer overrides
# can only tighten — i.e., set values in the range 0–90. If GCP
# returns "can only be set between 0 to N" with a different N, update
# the 0–90 validation in variables.tf.
#
# Discovered with:
#   gcloud alpha services quota list \
#     --service=aiplatform.googleapis.com \
#     --consumer=projects/<project_id>
#
# Forward-ready: no Agent workload exists yet in this project. The
# override takes effect the moment one is deployed.
########################
resource "google_service_usage_consumer_quota_override" "reasoning_engine_query_per_min" {
  for_each = var.subsidiaries
  provider = google-beta

  project        = data.google_project.subsidiary[each.key].number
  service        = "aiplatform.googleapis.com"
  metric         = urlencode("aiplatform.googleapis.com/reasoning_engine_service_query_requests")
  limit          = urlencode("/min/project/region")
  override_value = tostring(var.reasoning_engine_query_qpm)
  force          = true

  dimensions = {
    region = var.region_primary
  }

  depends_on = [google_project_service.gemini]
}
