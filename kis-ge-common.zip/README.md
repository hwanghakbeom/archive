# KIS Gemini Enterprise — 보안 통제 체크리스트

[codebase/tf/SCENARIOS.md](codebase/tf/SCENARIOS.md)에 정의된
**48개 사전 제어(Prevent) 시나리오**가 현재 GCP 환경
(`iac/envs/prd/`)에 어디까지 적용되었는지 보여주는 한국어 요약본
입니다. 영문 원본은 [docs/security-checklist.md](docs/security-checklist.md)
이며, 두 문서는 같은 정보를 담습니다.

## 범위 결정 사항

- **단일 프로젝트 토폴로지** — Discovery Engine / BigQuery /
  Cloud Storage / Agent Engine / 보안(DLP·Model Armor) / KMS 등
  모든 보안 리소스는 **`kis-gemini-enterprise`** 한 프로젝트에
  배포합니다. 별도 BQ / GCS / Agent / Security / KMS 프로젝트는
  두지 않으며, `codebase/tf/`의 다중 프로젝트 변수(
  `var.bq_project_id`, `var.gcs_project_id` 등)는 모두
  `kis-gemini-enterprise`로 매핑됩니다.
- **SCC Premium / Enterprise는 본 단계 제외** — Row 46–49는 이번
  단계의 범위 밖이며, SCC 티어 구매 후 재검토합니다.
- **Workforce Identity Federation 제외** — GE 인증은 Workspace
  (GSUITE) 단일 IdP 만 사용합니다.
- **운영 프로젝트 `kis-common-gcp`** — Terraform state + Cloud Build
  러너 호스트 전용입니다. 보안 리소스는 두지 않습니다.

## 상태 표기

- ✅ **적용 완료** — `iac/envs/prd/`에 코드가 있고, 대상 프로젝트에
  `terraform apply`가 성공적으로 수행됨.
- 🟡 **코드 준비됨, 적용 대기** — `iac/envs/prd/`에는 선언되어
  있으나 운영자 한 단계(예: `terraform import`, DNS 게시)를
  기다리는 상태. 또는 활용 사례가 아직 없어 의도적으로 보류.
- 🟦 **운영자 후속 작업** — 적용은 됐지만 콘솔 / 스모크 테스트로
  end-to-end 검증이 끝나지 않은 상태.
- 🔴 **조직/Workspace 레벨 — 권한 보류** — Cloud Admin(조직 ID
  `240369219899`) 또는 Workspace Admin(`koreainvestment.com`) 만
  적용 가능.
- ☐ **콘솔 전용** — Terraform 미지원. Workspace Admin Console /
  SCC Console에서 수동 설정.
- 🚫 **본 단계 제외** — SCC, WIF 등 명시적으로 보류한 항목.

### 소유자(Owner)

- **TF** — IaC 팀 (본 리포지토리)
- **Cloud Admin** — 조직 `240369219899` 관리자
- **Workspace Admin** — `koreainvestment.com` 테넌트 관리자
- **SecOps** — 보안운영팀 / SOC
- **Finance** — 유료 티어 / 라이선스 구매 담당

---

## 1. 현재 Terraform 상태 (2026-05-22 기준)

모든 리소스 대상 프로젝트는 `kis-gemini-enterprise`입니다.

### 1.1 Foundation (감사 + GE 앱)

| 상태 | 리소스 | TF 주소 |
|---|---|---|
| ✅ | 프로젝트 감사 로그 Sink (4종 audit log 전체) | `module.audit_log_export["kis"]` (`terraform-google-modules/log-export/google ~> 11.1`) |
| ✅ | GCS 감사 버킷 `gs://kis-gemini-enterprise-audit-logs` (보존 2,555일 **잠금 해제 상태**, UBLA, public-access enforced, versioning) | `module.audit_storage["kis"]` (`//modules/storage`) |
| ✅ | 10개 기본 API | `google_project_service.gemini[*]` — cloudresourcemanager, serviceusage, discoveryengine, storage, iam, aiplatform, modelarmor, dlp, datacatalog, cloudkms |
| ✅ | Discovery Engine 데이터스토어 (`ge-ds-29118f`) | `google_discovery_engine_data_store.gemini["kis"]` |
| ✅ | Discovery Engine 검색 엔진 (`ge-engine-29118f`, **`APP_TYPE_INTRANET`**) | `google_discovery_engine_search_engine.gemini["kis"]` |
| ✅ | ACL 설정 (`idp_type = "GSUITE"`) | `google_discovery_engine_acl_config.gemini["kis"]` |
| ✅ | Widget 설정 (`config_id = 2390b20d-fa11-442d-962e-c01a703c6c3d`) | `google_discovery_engine_widget_config.gemini["kis"]` |
| ✅ | IAM 모듈 호출 (`additive`; 멤버 리스트 현재 `[]`) | `module.iam_gemini["kis"]` (`terraform-google-modules/iam/google ~> 8.0`) |
| 🟡 | GE Assistant + Model Armor 바인딩 (`customer_policy.model_armor_config`; `failure_mode = "FAIL_OPEN"`; `web_grounding_type = "WEB_GROUNDING_TYPE_DISABLED"`) | `google_discovery_engine_assistant.gemini["kis"]` — **GE가 자동 생성하므로 자회사별로 `terraform import` 후 `apply` 필요** ([iac/README.md](iac/README.md) "Onboarding Subsidiary N" 5단계 참조) |

### 1.2 커스텀 도메인 LB (옵션 — 현재 `kis`에 대해 `expose_via_lb = true`)

| 상태 | 리소스 | TF 주소 |
|---|---|---|
| ✅ | compute API (옵션 활성화 시에만) | `google_project_service.lb_compute["kis"]` |
| ✅ | 정적 Anycast IP | `google_compute_global_address.lb["kis"]` |
| ✅ | Internet FQDN NEG + 엔드포인트 (`vertexaisearch.cloud.google.com:443`) | `google_compute_global_network_endpoint{_group,}.lb["kis"]` |
| ✅ | 백엔드 서비스 (host-header 재작성) | `google_compute_backend_service.lb["kis"]` |
| 🟦 | 매니지드 SSL 인증서 — 생성됨. DNS A 레코드(`kis-gemini.koreainvestment.com → lb_ip`) 게시 후 약 30분 내 ACTIVE 상태로 전환 | `google_compute_managed_ssl_certificate.lb["kis"]` |
| ✅ | URL Map (경로 재작성 `/home/cid/<gemini_app_id>`) | `google_compute_url_map.lb["kis"]` |
| ✅ | Target HTTPS Proxy | `google_compute_target_https_proxy.lb["kis"]` |
| ✅ | Global Forwarding Rule | `google_compute_global_forwarding_rule.lb["kis"]` |

### 1.3 프로젝트 레벨 보안 통제 (`security.tf`)

| 상태 | 리소스 | TF 주소 | 시나리오 |
|---|---|---|---|
| ✅ | KMS 키링 + 2개 키 (`bq-cmek`, `gcs-cmek`) — `asia-northeast3`. 키 레벨 IAM은 워크로드가 키를 소비할 때 부여하도록 보류 | `module.kms_data_keyring["kis"]` (`terraform-google-modules/kms/google ~> 4.0`) | Row 18 / 25 부분 |
| ✅ | Model Armor 템플릿 — **`us` 멀티 리전** — SDP + PI/Jailbreak + RAI 필터 | `google_model_armor_template.user_prompt_sanitize["kis"]` | Row 3, 5 |
| ✅ | DLP 비식별(De-identify) 템플릿 — **`us` 멀티 리전** — KOREA_RRN / KOREA_DRIVERS_LICENSE_NUMBER / KOREA_PASSPORT / CREDIT_CARD_NUMBER / EMAIL_ADDRESS 문자 마스킹 | `google_data_loss_prevention_deidentify_template.ge_response_deid["kis"]` | Row 4 |
| ✅ | DLP 검사(Inspect) 템플릿 (KR PII + 금융) — **`us` 멀티 리전** — KOREA_* 6종 + 범용 5종 | `google_data_loss_prevention_inspect_template.ge_inspect["kis"]` | Row 4, 추후 Discovery Configs에서 재사용 |
| ✅ | Data Catalog PII 분류 체계 (`PII_TAXONOMY`) — `asia-northeast3` | `google_data_catalog_taxonomy.pii_taxonomy["kis"]` | Row 14 |
| ✅ | Policy Tag (`confidential`, `internal`) | `google_data_catalog_policy_tag.pii_*["kis"]` | Row 14 |
| ✅ | Discovery Engine `conversational_search_read_requests` 쿼터 오버라이드 — `1/min/{project}`. 플랫폼이 오버라이드 범위를 **0–600**으로 제한(tighten 전용); `var.discoveryengine_conversational_qpm`로 조정 (기본 600 = 플랫폼 기본값에 명시적 핀) | `google_service_usage_consumer_quota_override.discoveryengine_conversational_per_min["kis"]` | Row 9 |
| ✅ | Vertex AI `reasoning_engine_service_query_requests` 쿼터 오버라이드 — `1/min/{project}/{region}`, region = `var.region_primary`. 범위 **0–90**(tighten 전용); `var.reasoning_engine_query_qpm`로 조정 (기본 90 = 플랫폼 기본값). Forward-ready: Agent 워크로드 배포 즉시 적용 | `google_service_usage_consumer_quota_override.reasoning_engine_query_per_min["kis"]` | Row 44 |

### 1.4 운영자 후속 작업 (추가 TF 코드 불필요 — 운영 단계)

1. **GE `default_assistant`를 `terraform import` 후 `terraform apply`** —
   Model Armor 바인딩이 실제 적용되도록. 구체 명령은
   [iac/README.md](iac/README.md) "Onboarding Subsidiary N" 5단계 참조.
2. **DNS A 레코드 게시** `kis-gemini.koreainvestment.com → <lb_ip>`.
   `lb_ip`는 `terraform output external_lb_endpoints`로 확인.
   DNS resolve 완료 후 약 30분 내 매니지드 인증서가 PROVISIONING →
   ACTIVE로 전환됩니다.
3. **LB 경로 스모크 테스트** (MZ guide §A-7):
   ```sh
   curl -kI https://kis-gemini.koreainvestment.com/test-app
   # 기대 결과: 302 → accounts.google.com (continue=vertexaisearch.cloud.google.com/home/cid/<gemini_app_id>)
   ```
4. **브라우저 스모크 테스트**: 로그인 → GE 앱 진입 → 가짜 KR 주민
   번호 형식(예: `950101-1234567`)을 포함한 채팅 요청을 보내, Model
   Armor + DLP 경로가 마스킹하는지 확인.
5. **콘솔 산출물 확인** — §4 참조.

### 1.4a VPC-SC 활성화 런북 (Row 7 / 16 / 26)

코드는 `iac/envs/prd/vpc-sc.tf`에 있고, 2026-05-22부터 **ENFORCE**
모드로 라이브 적용 중입니다 (`enable_vpc_sc = true`,
`vpc_sc_dry_run = false`).

#### 아키텍처 (현재 배포 상태)

- **제한 서비스 (5개):** aiplatform, storage, bigquery, dlp, cloudkms.
  `discoveryengine.googleapis.com`은 **의도적으로 제외** — Gemini
  Enterprise 최종 사용자가 글로벌 LB(`kis-gemini.koreainvestment.com`)
  로 접속하는데, 이들은 corporate access level에 포함되지 않으므로
  perimeter에서 discoveryengine을 제한하면 정상 서비스 트래픽이
  enforce 모드에서 차단됩니다.
- **Access Level `kis_corporate`:** members =
  `vpc_sc_allowed_members` (기본 `["user:snswang@mz.co.kr"]`),
  IP allowlist는 `vpc_sc_allowed_ip_ranges` (현재 빈 값). OR 조합.
- **단일 Ingress Rule:** identities = `vpc_sc_ingress_identities`
  (기본 `["user:snswang@mz.co.kr"]`), `sources.access_level = "*"`.
  Access Level과 belt-and-suspenders (Console / CLI 세션에서 Access
  Level의 `members:` 매칭이 가끔 실패하는 경우 대비).
- **`kis-common-gcp`(Terraform state를 보관하는 운영 프로젝트)는
  의도적으로 perimeter 외부.** 안에 두면 perimeter 위반이 이후
  `terraform apply`를 막을 수 있습니다.

#### 운영 계약 (enforce 모드 전제)

- **사람의 Console / CLI 세션:** 브라우저 BQ Console 쿼터 프로젝트를
  `kis-gemini-enterprise`로 핀(우측 상단 프로젝트 선택기); 임시
  `gcloud` 쿼터 프로젝트도 동일. 이를 지키지 않으면
  `kis-common-gcp`로 귀속된 호출이 perimeter 내부 리소스를 대상으로
  발생할 때 `RESOURCES_NOT_IN_SAME_SERVICE_PERIMETER`로 차단됨.
- **Terraform:** ADC 쿼터는 `kis-common-gcp` 유지 →
  `gs://kis-common-gcp-tfstate/` state 읽기가 perimeter 평가 대상이
  되지 않음 (source = target = kis-common-gcp). Provider의
  `billing_project = kis-gemini-enterprise`가 리소스 호출을 perimeter
  내부로 재귀속.

쿼터를 `kis-gemini-enterprise`로 핀하기가 현실적으로 어려운 상황이
생기면, `terraform.tfvars`의 `vpc_sc_ingress_source_projects`에
kis-common-gcp 프로젝트 번호(`207734967960`)를 추가하면 됩니다.
`vpc-sc.tf`의 dynamic 블록이 두 번째 ingress rule
(`sources.resource = "projects/207734967960"`)을 자동 생성하여
crossing을 bridge합니다. 단, GCP 제약상 `access_level = "*"`와
`sources.resource`는 같은 `ingress_from`에 공존할 수 없으므로
(`If IngressSource.access_level is set to '*', then only 1
IngressSource should be present`), dynamic 블록이 두 개의 별도
`ingress_policies` 블록으로 분리해 emit합니다.

#### 콜드 스타트 활성화 절차

1. **Cloud Admin**이 org `240369219899`의
   `roles/accesscontextmanager.policyAdmin`을 적용 ID에 부여.
   (`snswang@mz.co.kr`은 2026-05-22에 부여됨.)
2. **IaC 팀**이 `terraform.tfvars`에 `vpc_sc_allowed_ip_ranges`
   (KIS 회사 + VPN CIDR)를 설정하고, 비상 접근 그룹을
   `vpc_sc_allowed_members`에 추가. 적용자가 member 리스트에
   반드시 포함되도록 유지.
3. `enable_vpc_sc = true`로 전환 (DRY_RUN 유지). `terraform apply`.
4. **DRY_RUN 위반 로그 모니터링** (Cloud Logging). Ingress만 좁히면:
   ```
   resource.type="audited_resource"
   protoPayload.metadata.dryRun="true"
   protoPayload.metadata.ingressViolations.servicePerimeter:*
   ```
   각 항목 triage: 정상 접근 패턴 → 위 운영 계약대로 세션 쿼터
   조정 (구조적으로 필요하면 access level / ingress rule 추가);
   의심스러우면 perimeter가 정상 동작 중인 증거.
5. 운영 계약을 따르는 경로에서 ingress 위반이 0이 되면 별도 결재
   MR로 `vpc_sc_dry_run = false` 전환 → 강제 모드 발효. Egress
   위반(perimeter 내부 → 외부 프로젝트 호출, 예: `bigquery-public-data`)
   은 설계상 정상 신호이므로 차단 블로커가 아님 — BQ 워크로드는
   `kis-gemini-enterprise` 내부에서 운영.

#### 위반 진단

- `violationReason = NO_MATCHING_ACCESS_LEVEL` → 호출자가 access
  level 외부이며 ingress rule에도 매칭되지 않음. 조치:
  `vpc_sc_allowed_members` 또는 `vpc_sc_ingress_identities`에 추가,
  혹은 세션 쿼터 프로젝트를 올바르게 핀.
- `violationReason = RESOURCES_NOT_IN_SAME_SERVICE_PERIMETER` →
  cross-perimeter 프로젝트 crossing (예: 쿼터 프로젝트는 외부, 대상은
  내부). 조치: 같은 perimeter의 프로젝트로 쿼터 핀하거나,
  `vpc_sc_ingress_source_projects`에 source 프로젝트 번호 추가.
- `violationReason = SERVICE_NOT_ALLOWED_FROM_VPC` → perimeter
  내부에서 비허용 egress 경로 사용. 보통 비-Google IP로 빠진 경우.
  이 토폴로지에선 일반적이지 않음 — 에스컬레이션.

ADC ID와 gcloud config는 별도 자격 증명 저장소이므로, perimeter를
의심하기 전에 ADC ID부터 확인:
```
curl -s "https://oauth2.googleapis.com/tokeninfo?access_token=$(gcloud auth application-default print-access-token)" | jq .email
```

### 1.5 백로그 — 데이터만 확보되면 작은 TF 수정으로 끝낼 수 있는 항목

- `subsidiaries.kis.gemini_admin_members` / `gemini_end_user_members`
  값 채우기 (실제 Workspace 그룹 주소 확정 후). `module.iam_gemini`가
  additive 모드이므로 2개 바인딩이 추가됨.
- `var.enable_data_access_audit = true`로 전환 — 자회사별
  `google_project_iam_audit_config`가 생성되어 `kis-gemini-enterprise`
  에 대한 DATA_READ / DATA_WRITE 감사 로그가 흐릅니다 (Row 8 일부).
  로그 볼륨/비용 모니터링 필요.
- `var.lock_retention = true`로 전환 — **별도 결재 MR**로 처리
  (irreversible, 버킷당 1회).
- Model Armor 바인딩의 `failure_mode = "FAIL_CLOSED"`로 전환 — Model
  Armor 강제 경로가 end-to-end 검증된 이후.
- (Row 9 + Row 44 모두 적용 완료 — 추가 백로그 없음.)

---

## 2. 시나리오 매트릭스 (Row 2–49)

### Gemini Enterprise App (Row 2–12)

| Row | 시나리오 | 상태 | 비고 |
|---|---|---|---|
| 2 | 비인가 사용자 접근 | ✅ 일부 / 🔴 일부 | **✅** `module.iam_gemini` 적용 (그룹 비어 있음). **TF 백로그:** 실제 그룹 주소 확보 시 `gemini_admin_members` / `gemini_end_user_members` 채우기. **🔴** Org Policy `iam.allowedPolicyMemberDomains` — Cloud Admin. |
| 3 | Prompt 민감 데이터 입력 | ✅ / 🟡 / ☐ | **✅** Model Armor 템플릿 적용 (`us`; SDP + PI/Jailbreak + RAI). **🟡** GE 엔진 바인딩은 `google_discovery_engine_assistant.customer_policy.model_armor_config.user_prompt_template`로 선언됨 — GE가 `default_assistant`를 자동 생성하므로 1회 `terraform import` 후 `apply` 필요. **☐ SecOps:** 보안교육 LMS 모듈 등재; 통합 검증 후 `failure_mode = "FAIL_CLOSED"`로 전환. |
| 4 | Gemini 응답 민감 데이터 노출 | ✅ / 🟡 / ☐ | **✅** DLP 비식별 + 검사 템플릿 적용 (`us`; KOREA_* 6종 + 범용 5종). Model Armor 템플릿이 응답측 sanitizer 역할 겸용(현재 양 방향 동일 템플릿). **🟡** Row 3과 동일한 import-then-apply로 바인딩 활성화. **☐ SecOps:** Discovery Engine 인덱싱 거버넌스 Runbook; 향후 prompt-only / response-only 템플릿 분리 검토. |
| 5 | Prompt Injection / Jailbreak | ✅ | Row 3 Model Armor 템플릿의 `pi_and_jailbreak_filter_settings`에 포함. |
| 6 | 외부망 / 비관리 디바이스 접근 | 🔴 + ☐ | **🔴** Access Context Manager Access Level — 조직 레벨 Access Policy 선행 필요. **☐ Finance:** Chrome Enterprise Premium 라이선스. **☐ Workspace:** BeyondCorp Console에서 Device posture 정책. |
| 7 | VPC-SC: 외부 서비스 데이터 유출 | ✅ (ENFORCED) | 2026-05-22부터 enforce 모드 라이브 (`enable_vpc_sc = true`, `vpc_sc_dry_run = false`). 위반은 **차단**됨 (로그만 기록이 아님). **제한 서비스 5개**: aiplatform + storage + bigquery + dlp + cloudkms. `discoveryengine.googleapis.com`은 **의도적으로 제외** — Gemini Enterprise 최종 사용자가 LB(`kis-gemini.koreainvestment.com`)로 접속하므로(corporate access level 미포함) 제한하면 정상 트래픽이 차단됨, §1.4a 참조. 단일 ingress rule로 `snswang@mz.co.kr`을 모든 source에서 admit. 운영 계약: 사람의 Console/CLI 쿼터 프로젝트를 `kis-gemini-enterprise`로 핀. |
| 8 | Audit Log 비활성화 | ✅ 일부 / 🔴 일부 | **✅** 프로젝트 sink + 버킷 적용 (kis-gemini-enterprise 감사 로그 커버). `DATA_READ` 흐르게 하려면 `var.enable_data_access_audit = true` (`google_project_iam_audit_config` 생성). **🔴** 조직 집계 Sink + Org IAM Audit Config — Cloud Admin. **☐ Workspace:** `gcloud organizations enable-access-transparency`. |
| 9 | Quota / 사용량 남용 | ✅ | `google_service_usage_consumer_quota_override.discoveryengine_conversational_per_min`이 `discoveryengine.googleapis.com/conversational_search_read_requests`(Assistant 채팅 read 경로)에 오버라이드. **이 metric은 consumer 오버라이드 범위가 0–600으로 제한**(GCP 기본값 600을 상회하려면 별도 쿼터 증액 요청 필요). 기본 600(명시적 핀); 낮추면 abuse 보호 강화. 코드베이스 예시(`queries` metric)는 실제로 존재하지 않아 `gcloud alpha services quota list`로 실 ID 확인 후 적용. |
| 10 | 필수 API 임의 비활성화 | 🔴 + ☐ | **🔴** Org Policy `serviceuser.services` allow-list — Cloud Admin. **☐ SecOps:** `roles/serviceusage.serviceUsageAdmin` JIT 발급 PAM 워크플로. |
| 11 | 3rd-party Connector 유출 | 🔴 + ☐ | **🔴** Org Firewall Policy — Cloud Admin + 조직 VPC 계획. **☐ SecOps:** Connector SA 키 회전 자동화(Cloud Scheduler + Functions). |
| 12 | 허용 리전 외 자원 생성 | 🔴 | **🔴** Org Policy `gcp.resourceLocations` (allow `in:asia-northeast3-locations`) — Cloud Admin. |

### BigQuery (Row 13–20) — KMS 키링 준비 완료, BQ 워크로드 아직 없음

| Row | 시나리오 | 상태 | 비고 |
|---|---|---|---|
| 13 | 데이터셋 권한 과다 부여 | 🟡 | BQ 데이터셋 + Workspace 그룹(`bq-readers@`, `bq-editors@`, `bq-users@`) 확보 시 적용. `iam_gemini`와 동일 패턴 (`terraform-google-modules/iam/google//modules/projects_iam`). |
| 14 | PII 미식별 / 미분류 | ✅ 일부 / 🟡 일부 | **✅** Data Catalog `PII_TAXONOMY` + Policy Tag(`confidential`, `internal`) 적용. 컬럼 태깅은 BQ 스키마 생성 시점 작업. **🟡 BQ DLP Discovery Config**는 보류 — 유료 스캔 기능 + BQ 테이블 부재. |
| 15 | Authorized View / Dataset 미사용 | 🟡 | 패턴만 제공; 실제 `google_bigquery_dataset_access`는 데이터셋 단위 추가. |
| 16 | 대량 Export / Exfiltration | ✅ (ENFORCED) | Row 7/26과 동일 enforced perimeter — `bigquery.googleapis.com`이 `var.vpc_sc_restricted_services`에 포함. Access Level / perimeter 외부에서의 대량 BQ export는 perimeter에 의해 **차단**됨. |
| 17 | Row / Column Level Access | 🟡 | Policy Tag taxonomy 준비됨(Row 14). 실제 컬럼-태그 바인딩 + `google_bigquery_row_access_policy`는 테이블 단위. |
| 18 | CMEK 미적용 | ✅ 일부 / 🔴 일부 | **✅** KMS 키링 + `bq-cmek` 키 생성됨. **🔴** Org Policy `gcp.restrictNonCmekServices`로 강제 — Cloud Admin. 데이터셋 단위 `default_encryption_configuration`은 데이터셋별. |
| 19 | Quota / Cost 폭증 | 🚫 | BQ `ENTERPRISE` Reservation은 실비용 발생 — BQ 사용 시작 후로 보류. 쿼리별 `maximum_bytes_billed`은 BI 도구 측 설정. |
| 20 | BQ Data Access Audit Log 비활성 | 🔴 | bigquery.googleapis.com용 조직 레벨 `google_organization_iam_audit_config` — Cloud Admin. |

### Cloud Storage (Row 21–28)

| Row | 시나리오 | 상태 | 비고 |
|---|---|---|---|
| 21 | 버킷 Public 노출 | ✅ 일부 / 🔴 일부 | **✅** 감사 버킷은 `public_access_prevention = "enforced"`. **🔴** Org Policy `storage.publicAccessPrevention`로 모든 버킷에 강제 — Cloud Admin. |
| 22 | UBLA 미적용 | ✅ 일부 / 🔴 일부 | **✅** 감사 버킷은 UBLA 활성. **🔴** Org Policy `storage.uniformBucketLevelAccess` — Cloud Admin. |
| 23 | GCS PII 분류 미수행 | 🟡 | GCS DLP Discovery Config 보류 — 유료 스캔, 현재 감사 버킷 외에 스캔 대상 없음(감사 로그를 PII 스캔하는 것은 부적절). `google_data_loss_prevention_inspect_template.ge_inspect` 재사용 예정. |
| 24 | 버전 관리 / Retention 미설정 | ✅ 일부 / 🟡 일부 | **✅** 감사 버킷은 versioning + 2,555일 보존(잠금 해제). **🟡** 향후 GCS 워크로드 버킷에도 동일 템플릿(`kr_secure_bucket_template`) 적용 — CMEK는 `module.kms_data_keyring.keys["gcs-cmek"]` 사용. |
| 25 | CMEK 미적용 | ✅ 일부 / 🔴 일부 | **✅** KMS `gcs-cmek` 키 생성됨. **🔴** Org Policy `gcp.restrictNonCmekServices` — Cloud Admin. 버킷별 `encryption.default_kms_key_name`은 버킷별. |
| 26 | VPC-SC Perimeter 우회 | ✅ (ENFORCED) | Row 7/16과 동일 enforced perimeter. `storage.googleapis.com` + Access Level이 GCS 우회 벡터 커버 — perimeter 외부 / access level 외부에서의 GCS 호출은 perimeter에 의해 **차단**됨. |
| 27 | IAM Conditions 미사용 | 🟡 | 코드베이스에 패턴 존재; 프로젝트 레벨. 구체적인 활용 사례(예: 시간 제한된 `internal-readers@` 그룹 접근)에 맞춰 적용. |
| 28 | GCS Data Access Audit Log 비활성 | 🔴 | storage.googleapis.com용 조직 레벨 `google_organization_iam_audit_config` — Cloud Admin. |

### Cloud Identity (Row 29–38) — Workspace Admin의 `workspace_customer_id` 필요

| Row | 시나리오 | 상태 | 비고 |
|---|---|---|---|
| 29 | 2단계 인증(MFA) | 🔴 + ☐ | TF 그룹 정의에 `workspace_customer_id` 필요. **☐ Workspace:** 2-Step Verification Enforcement ON / Security Key Only. |
| 30 | Admin Advanced Protection | 🔴 + ☐ | TF 그룹 정의에 `workspace_customer_id` 필요. **☐ SecOps:** APP self-enrollment 안내 + 분기 점검. |
| 31 | 의심스러운 로그인 | 🔴 | Access Context Manager Access Level — Cloud Admin Access Policy. |
| 32 | OAuth 앱 무단 승인 | ☐ | **☐ Workspace:** Admin Console → Security → API Controls → Restricted scopes (`cloud-platform`, `iam`, `aiplatform`), App Access Control = "Trusted apps only". |
| 33 | 외부 멤버 차단 | 🔴 + ☐ | Row 2 Org Policy로 일부 처리. **☐ Workspace:** Group settings `Allow members from outside this organization` = OFF. |
| 34 | SA Key 노출 / 장기 미회전 | 🔴 | **🔴** Org Policy `iam.disableServiceAccountKey*` — Cloud Admin. |
| 35 | 비활성 / 퇴사자 계정 | ☐ + ☐ | **☐ Workspace:** Auto-suspend 90일. **☐ SecOps:** Recommender 자동 회수 자동화. |
| 36 | Access Approval 미설정 | 🔴 | `google_organization_access_approval_settings` — Cloud Admin. |
| 37 | Cloud Shell 차단 | ☐ + ☐ | **☐ Workspace:** Cloud Shell = OFF (전체). **☐ Alternative:** Cloud Workstations 별도 배포. |
| 38 | 민감 자원 Data Access Log 비활성 | 🔴 | discoveryengine + aiplatform + iam에 대한 조직 레벨 audit config — Cloud Admin. |

### Agent Engine (Row 39–45) — 단일 프로젝트 = `kis-gemini-enterprise`; agent 워크로드 미배포

| Row | 시나리오 | 상태 | 비고 |
|---|---|---|---|
| 39 | Agent SA 과대 권한 | 🟡 | agent SA 존재 시 적용; `safe_*` 데이터셋 prefix 조건부 IAM은 프로젝트 로컬. |
| 40 | Function Calling Tool 악용 | ☐ | **☐ Code:** agent 코드의 input schema validation + CI 검증. |
| 41 | Agent Prompt / Code Tampering | 🟡 | Binary Authorization — **프로젝트 내 비-attested 컨테이너 배포를 모두 차단**. CI/CD attestor 파이프라인 구축 후 적용. |
| 42 | Agent External API / Tool 무단 호출 | 🔴 | Org Firewall Policy — Cloud Admin. |
| 43 | Agent 응답 민감 데이터 노출 | ✅ | Row 3 / 4의 Model Armor + DLP 템플릿 재사용 (이미 적용). |
| 44 | Agent 무한 추론 | ✅ | `google_service_usage_consumer_quota_override.reasoning_engine_query_per_min`이 `aiplatform.googleapis.com/reasoning_engine_service_query_requests`(Vertex AI Reasoning Engine 쿼리 경로; regional, `var.region_primary` scope)에 오버라이드. `var.reasoning_engine_query_qpm`로 조정(기본 90 = 플랫폼 기본값, 범위 0–90 tighten 전용). Forward-ready: Agent 워크로드 배포 시 즉시 abuse 방어 적용. 코드베이스 예시(`online_prediction_requests` metric)는 실제로 존재하지 않아 `gcloud alpha services quota list`로 실 ID 확인 후 적용. |
| 45 | Agent SA Impersonation 남용 | 🟡 | agent SA + agent-operators 그룹 존재 시 적용. WIF 범위 제외 — 코드베이스의 `google_iam_workload_identity_pool`은 **생략**. |

### SCC Premium / Enterprise (Row 46–49) — 🚫 본 단계 제외

| Row | 시나리오 | 상태 |
|---|---|---|
| 46 | IAM 이상 행위 (ETD) | 🚫 |
| 47 | Attack Path 미식별 | 🚫 |
| 48 | PII / 금융정보 분류 누락 | 🚫 |
| 49 | 위협 인텔리전스 미연동 | 🚫 |

SCC Premium 티어 구매 후 재검토.

---

## 3. 담당자별 후속 작업

### 3.1 IaC 팀 — tfvars 변경만으로 가능, 추가 권한 불필요

- [ ] **Workspace 그룹 채우기 (Row 2 백로그)**: Workspace 그룹 주소
  확보 시 `terraform.tfvars`의 `subsidiaries.kis.gemini_admin_members` /
  `gemini_end_user_members` 설정 → `module.iam_gemini`가 2개 IAM
  바인딩을 additive로 추가.
- [ ] **`var.enable_data_access_audit = true`로 전환** (Row 8):
  자회사별 `google_project_iam_audit_config` 생성 → 기존 sink에
  DATA_READ / DATA_WRITE 흐름. 로그 볼륨 비용 모니터링.
- ~~Vertex AI 쿼터 오버라이드(Row 44) 재추가~~ — 적용 완료
  (`google_service_usage_consumer_quota_override.reasoning_engine_query_per_min`).

### 3.2 IaC 팀 — 사전조건 충족 시 코드 작업

- [ ] **Row 14 — BQ DLP Discovery Config**: BQ 테이블 생성 후
  `codebase/tf/modules/bigquery.tf`의
  `google_data_loss_prevention_discovery_config.bq_discovery`를 옮겨
  적용 (inspect template은 `ge_inspect` 재사용). **비용 주의:** DLP
  Discovery는 스캔 리소스당 과금.
- [ ] **Row 23 — GCS DLP Discovery Config**: 감사 외 GCS 버킷 생성
  후 동일 패턴.
- [ ] **Row 24 — Secure GCS bucket template**: 워크로드 GCS 버킷
  생성 시 `codebase/tf/modules/cloud_storage.tf`의
  `kr_secure_bucket_template` 패턴(versioning + retention + CMEK via
  `module.kms_data_keyring.keys["gcs-cmek"]`).
- [ ] **Row 13 — BQ IAM 모듈**: BQ 데이터셋 + Workspace 그룹 확보 시
  `terraform-google-modules/iam/google//modules/projects_iam`로
  bq-readers / bq-editors / bq-users 바인딩.
- [ ] **Row 39 / 45 — Agent IAM**: agent SA 존재 시 conditional IAM
  바인딩 추가.

### 3.3 Cloud Admin — 조직 `240369219899` 결재 필요

조직 전역에 영향을 주는 항목이므로, 각각 별도 MR로 명시적 승인을
받아 적용하는 것을 권장합니다.

- [ ] **`roles/accesscontextmanager.policyAdmin`** 권한을 org
  `240369219899`의 Terraform applier(`snswang@mz.co.kr`)에 부여 —
  Row 6 / 7 / 16 / 26 / 31 잠금 해제. 권한 부여 후 `vpc-sc.tf`의
  `var.enable_vpc_sc = true`로 전환하면 Terraform이 Access Policy +
  Access Level + Service Perimeter를 자동 생성.
- [ ] **Org Policies:**
  - `iam.allowedPolicyMemberDomains` (Row 2 / 33)
  - `serviceuser.services` allow-list (Row 10)
  - `gcp.resourceLocations` (Row 12)
  - `gcp.restrictNonCmekServices` (Row 18 / 25) — BQ / GCS 워크로드에
    CMEK가 통합된 후
  - `storage.publicAccessPrevention` (Row 21)
  - `storage.uniformBucketLevelAccess` (Row 22)
  - `iam.disableServiceAccountKeyCreation` +
    `iam.disableServiceAccountKeyUpload` (Row 34)
- [ ] **Org IAM Audit Config** — discoveryengine, aiplatform,
  bigquery, storage, iam (Row 8, 20, 28, 38).
- [ ] **Org Aggregated Sink** (Row 8) — 중앙 집중 로그 저장소가
  필요해질 경우 (현재는 자회사별 버킷 유지).
- [ ] **Org Access Approval** (Row 36).
- [ ] **Org Firewall Policies** (Row 11, 42) — 조직 VPC 계획 확정 후.
- [ ] **`gcloud organizations enable-access-transparency`** (Row 8).

### 3.4 Workspace Admin (`koreainvestment.com` 테넌트)

- [ ] **`workspace_customer_id`** (`C0...`) 제공 — Row 29 / 30 / 33
  TF 그룹 정의에 필요.
- [ ] **Workspace 그룹 주소** 제공 — `gemini_admin_members` /
  `gemini_end_user_members` (Row 2 백로그).
- [ ] **콘솔 설정** (TF 미지원):
  - 2-Step Verification Enforcement ON (Row 29)
  - 관리자 그룹 APP self-enrollment 안내 (Row 30)
  - API Controls → Restricted scopes (Row 32)
  - Group settings: `Allow external members` = OFF (Row 33)
  - User Lifecycle: Auto-suspend 90일 (Row 35)
  - Additional Google services → Cloud Shell = OFF (Row 37)

### 3.5 Finance + SecOps — 유료 기능

- [ ] **Chrome Enterprise Premium** (Row 6) — Device posture
  (Endpoint Verification)에 필수.
- [ ] **DLP Discovery 스캔** (Row 14, 23) — 스캔 단위 과금; BQ / GCS
  워크로드 도입 시 예산 결재 후 활성화.
- [ ] *(보류)* SCC Premium 티어 (Row 46–49).

### 3.6 SecOps — 운영 Runbook (TF 미해당)

- [ ] **Row 3**: 보안교육 LMS 모듈 + 분기 캠페인.
- [ ] **Row 4**: Discovery Engine 인덱싱 거버넌스 Runbook + Cloud
  Workflows DLP 스캔 단계.
- [ ] **앱 레벨 통합**: Model Armor + DLP 템플릿을 GE 앱 / Agent 응답
  경로에 실제로 연결 (현재 템플릿은 아티팩트로만 정의됨, 활성 강제는
  Assistant import 이후).
- [ ] **Row 10**: `roles/serviceusage.serviceUsageAdmin` JIT 발급
  PAM 워크플로.
- [ ] **Row 11**: Connector SA 키 회전 자동화 (Cloud Scheduler +
  Cloud Functions).
- [ ] **Row 19**: BI 도구 `maximum_bytes_billed` 강제 + BQ Admin
  코드 검수.
- [ ] **Row 35**: Recommender 자동 회수 스크립트.
- [ ] **Row 40**: Agent input schema validation + CI 단계.

---

## 4. `kis-gemini-enterprise` 콘솔 측 후속 점검

현재 TF 배포 직후 **GCP Console**에서 실시할 즉시 후속 작업입니다.

1. **GE 앱 스모크 테스트** — `https://console.cloud.google.com/gen-app-builder?project=kis-gemini-enterprise`
   → `ge-engine-29118f` 클릭 → **Intranet** 앱으로 보이는지 확인.
2. **감사 로그 검증** — 샘플 이벤트 발생
   (`gcloud iam roles list --project=kis-gemini-enterprise`) →
   `gs://kis-gemini-enterprise-audit-logs/cloudaudit.googleapis.com/...`
   에 JSON 라인이 수 분 내 적재되는지 확인.
3. **LB 인증서 ACTIVE 전환** — DNS A 레코드
   `kis-gemini.koreainvestment.com → <lb_ip>` 게시 후
   `gcloud compute ssl-certificates describe <cert>`가
   `ACTIVE`가 될 때까지 모니터링 (약 30분).
4. **`gemini_app_id` 검증** — GE 엔진 → Integration 탭 →
   `/home/cid/` 뒤의 path 세그먼트가 tfvars 값과 일치하는지 확인.
   불일치 시 tfvars 수정 후 재적용.
5. **Model Armor 템플릿 가시성** —
   `https://console.cloud.google.com/security/model-armor?project=kis-gemini-enterprise`
   → 리전 셀렉터를 **`us` (multi-region)**으로 전환 →
   `ge-user-prompt-sanitize` 템플릿 확인. (SDP 필터가 DLP를
   호출하는데 KR_* 디텍터는 `us` 멀티 리전에서만 해석되기 때문에
   `us`에 핀.)
5a. **Model Armor → GE Assistant 바인딩** — GE 콘솔에서 엔진 클릭 →
   Configurations → assistant의 safety / customer-policy 섹션이
   `ge-user-prompt-sanitize` 템플릿을 prompt / response 양쪽에 참조
   하는지 확인. 스모크 테스트: 가짜 KR_RRN 문자열을 포함한 채팅
   요청 → 마스킹 여부 확인.
6. **DLP 템플릿** — Security → Sensitive Data Protection → location
   을 **`us` (multi-region)**으로 전환 → Templates →
   `GE Response De-identification` + `KR PII + Finance Inspect`
   확인. Model Armor와 동일 리전 제약.
7. **Data Catalog 분류 체계** — Data Catalog → Policy Tag taxonomies
   → `PII_TAXONOMY`와 `confidential` / `internal` 태그 확인.
8. **쿼터 오버라이드** — APIs & Services → Quotas → `Conversational
   search read requests` 필터 → `Effective` 값이
   `var.discoveryengine_conversational_qpm`(기본 600)와 일치하는지
   확인. 이어서 `Query Reasoning Engine requests` 필터 →
   `var.reasoning_engine_query_qpm`(기본 90)이 `var.region_primary`
   에 `Effective`로 표시되는지 확인.
9. **KMS 키링** — Security → Key Management → `asia-northeast3` →
   `kr-data-keyring`의 키 `bq-cmek` + `gcs-cmek` 확인. 워크로드(BQ
   데이터셋, GCS 버킷)가 CMEK를 실제로 사용하기 시작하면 그 시점에
   Encrypter / Decrypter 권한을 워크로드 SA에 부여.

---

## 5. 변경 이력

| 일자 | 변경 내용 | 담당 |
|---|---|---|
| 2026-05-21 | Phase 1 첫 apply 이후 체크리스트 초안 작성 | snswang@mz.co.kr |
| 2026-05-21 | 범위를 단일 프로젝트로 좁히고 SCC 보류. Tier 1 보안 통제(Row 3, 4, 9, 14 일부, 18/25 일부, 44)를 `iac/envs/prd/security.tf`에 추가 | snswang@mz.co.kr |
| 2026-05-21 | `security.tf`에서 Row 9 + Row 44 쿼터 오버라이드 제거 (코드베이스 metric ID가 `COMMON_QUOTA_LIMIT_NOT_FOUND` 반환). `gcloud services quota list`로 ID 발굴 후 재추가하도록 🟡 보류 표시 | snswang@mz.co.kr |
| 2026-05-22 | DLP 비식별 + 검사 템플릿 + Model Armor 템플릿을 `us` 멀티 리전으로 핀(KR_RRN / KR_DLN / KR_PASSPORT 디텍터가 asia-northeast3에서 미가용). KMS + Data Catalog는 그대로 asia-northeast3. `local.security_templates_location` 상수 추가 | snswang@mz.co.kr |
| 2026-05-22 | `var.billing_project` 추가 + 양 google provider에 `billing_project = var.billing_project` 설정 — DLP / Model Armor 리소스는 `parent`만 갖고 `project` 인자가 없으므로 `user_project_override = true`만으로는 기본 consumer 프로젝트로 폴백됨 | snswang@mz.co.kr |
| 2026-05-22 | DLP info-type 이름 정정: `KR_*`(미존재) → `KOREA_*`. 금융 관련 `KOREA_BRN` / `KOREA_ARN` / `KOREA_NHI_NUMBER` 추가 (DLP REST API `GET /v2/locations/us/infoTypes`로 검증) | snswang@mz.co.kr |
| 2026-05-22 | Model Armor 템플릿을 GE 엔진에 `google_discovery_engine_assistant.customer_policy.model_armor_config`로 와이어링 (Row 3 + 4 실제 강제). `failure_mode = "FAIL_OPEN"`, `web_grounding_type = "WEB_GROUNDING_TYPE_DISABLED"` | snswang@mz.co.kr |
| 2026-05-22 | Onboarding 함정: GE는 엔진당 `default_assistant`를 자동 생성하므로 assistant 리소스의 첫 `apply` 전에 자회사별 1회 `terraform import` 필요. Onboarding flow에 문서화. TF ≥ 1.7로 업그레이드 시 선언형 `for_each` import block 가능 | snswang@mz.co.kr |
| 2026-05-22 | §1을 리소스별 상태(✅ 적용 / 🟡 적용 대기 / 🟦 운영자 후속)로 재구성. KOREA_* + `us` 리전 + `billing_project` 수정 후 보안 템플릿(Model Armor, DLP, KMS, Data Catalog) 모두 ✅ 적용 완료. 남은 항목: GE Assistant `terraform import`, LB 매니지드 인증서 DNS 게시 | snswang@mz.co.kr |
| 2026-05-22 | 한국어 README.md 작성 (영문은 `docs/security-checklist.md` 유지) | snswang@mz.co.kr |
| 2026-05-22 | Row 9 구현: `discoveryengine.googleapis.com/conversational_search_read_requests`(`/min/{project}`)에 `google_service_usage_consumer_quota_override` 적용. 값은 `var.discoveryengine_conversational_qpm`(기본 1000)로 조정. 실 metric ID는 `gcloud alpha services quota list`로 확인 | snswang@mz.co.kr |
| 2026-05-22 | Row 9 수정: 이 metric은 consumer 오버라이드 범위가 **0–600**으로 제한됨(tighten 전용). `var.discoveryengine_conversational_qpm` 기본값 1000 → 600 + 0–600 validation 추가 | snswang@mz.co.kr |
| 2026-05-22 | Row 44 구현: `aiplatform.googleapis.com/reasoning_engine_service_query_requests`(`/min/{project}/{region}`, regional via `dimensions = { region = var.region_primary }`)에 `google_service_usage_consumer_quota_override` 적용. 값은 `var.reasoning_engine_query_qpm`(기본 90, 범위 0–90)로 조정. Agent 워크로드 배포 즉시 abuse 방어 동작. 실 metric ID는 `gcloud alpha services quota list`로 확인 | snswang@mz.co.kr |
| 2026-05-22 | Row 7 / 16 / 26 코드 작성: `iac/envs/prd/vpc-sc.tf` (Access Policy + Access Level + Service Perimeter, DRY_RUN 기본, member + IP allowlist, `prevent_destroy`). `var.enable_vpc_sc = false` 게이트로 `policyAdmin` 권한 부재 시 apply 안전(`snswang@mz.co.kr`이 현재 권한 부족). `accesscontextmanager.googleapis.com` 관리 API 목록 추가. §1.4a에 런북 신규 추가 | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC enforce 모드 시도: `vpc_sc_dry_run = false`로 apply 후 snswang의 Terraform state 읽기 + BigQuery Console이 `SecurityPolicyViolated`로 차단 (snswang이 access level + ingress policy에 모두 포함되어 있음에도). DRY_RUN으로 롤백. **미해결:** 3개의 `vpcServiceControlsUniqueIdentifier`를 Logs Explorer에서 triage 필요. **운영 함정:** Terraform billing-project 귀속으로 perimeter 외부 대상 호출도 perimeter 평가 대상이 됨 — 우회: state ops 동안 `gcloud auth application-default set-quota-project kis-common-gcp`. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC 근본 원인 Logs Explorer로 확인: `violationReason = RESOURCES_NOT_IN_SAME_SERVICE_PERIMETER` — cross-perimeter 프로젝트 crossing (쿼터 프로젝트 외부, 대상 내부). `access_level = "*"`는 identity-context source만 admit, project-context는 admit하지 않음. `var.vpc_sc_ingress_source_projects` + dynamic ingress 블록 추가로 `sources.resource = "projects/<NUMBER>"` 통한 bridge 가능. GCP 제약 발견: `access_level = "*"`와 `sources.resource`는 동일 `ingress_from`에 공존 불가 → 두 `ingress_policies` 블록으로 분리. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC: cross-project bridge (Rule B) 제거. 운영 계약으로 대체: 사람의 Console/CLI 세션은 브라우저 쿼터 프로젝트를 `kis-gemini-enterprise`로 핀; Terraform은 이중 자격 증명 유지 (ADC 쿼터 = kis-common-gcp는 state ops용; provider `billing_project = kis-gemini-enterprise`는 리소스 ops용). `var.vpc_sc_ingress_source_projects = []`로 tfvars 설정; 변수 + dynamic 블록은 코드에 유지하여 한 줄 수정으로 재활성화 가능. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC: `discoveryengine.googleapis.com`을 `var.vpc_sc_restricted_services`에서 제거. 사유: Gemini Enterprise 최종 사용자가 글로벌 LB(`kis-gemini.koreainvestment.com`)로 접속하며 corporate access level에 미포함 — discoveryengine 제한 시 enforce 모드에서 정상 서비스 트래픽 차단됨. 제한 서비스 5개 유지: aiplatform, storage, bigquery, dlp, cloudkms. Discovery Engine은 IAM + Row 9 쿼터 오버라이드로 계속 통제. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC ENFORCE 모드로 전환 (`vpc_sc_dry_run = false`). Row 7 / 16 / 26 상태 ✅ (ENFORCED). 5개 제한 서비스에 대해 access level 외부 / perimeter 외부 호출은 로그만 기록되는 게 아니라 차단됨. 진단 규칙 + 운영 계약은 §1.4a; `terraform.tfvars`의 구식 "don't flip" 경고는 해소 후 상태에 맞게 교체. | snswang@mz.co.kr |
