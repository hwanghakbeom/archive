########################
# Per-subsidiary audit log sink + GCS destination (independent per project).
# No central logging project — each subsidiary's audit logs stay in its own project.
# Adopts the official terraform-google-modules/log-export module.
########################

locals {
  # Default bucket name = "<project_id>-audit-logs" — globally unique because
  # project_id is. Override per-subsidiary via subsidiaries[*].audit_bucket_name
  # if/when that field is added later.
  audit_bucket_names = { for k, v in var.subsidiaries : k => "${v.project_id}-audit-logs" }

  audit_filter = <<-EOT
    logName:"/logs/cloudaudit.googleapis.com%2Factivity"
    OR logName:"/logs/cloudaudit.googleapis.com%2Fdata_access"
    OR logName:"/logs/cloudaudit.googleapis.com%2Fsystem_event"
    OR logName:"/logs/cloudaudit.googleapis.com%2Fpolicy"
  EOT
}

module "audit_log_export" {
  source   = "terraform-google-modules/log-export/google"
  version  = "~> 11.1"
  for_each = var.subsidiaries

  log_sink_name          = "krinvest-${each.key}-audit-to-gcs"
  parent_resource_id     = each.value.project_id
  parent_resource_type   = "project"
  unique_writer_identity = true

  # Compute destination_uri directly from the (known) bucket name to break
  # the module expansion cycle that for_each creates between log_export and
  # storage. Format matches what the storage submodule would emit.
  destination_uri = "storage.googleapis.com/${local.audit_bucket_names[each.key]}"

  filter = local.audit_filter
}

module "audit_storage" {
  source   = "terraform-google-modules/log-export/google//modules/storage"
  version  = "~> 11.1"
  for_each = var.subsidiaries

  project_id                  = each.value.project_id
  storage_bucket_name         = local.audit_bucket_names[each.key]
  log_sink_writer_identity    = module.audit_log_export[each.key].writer_identity
  location                    = var.region_primary
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  versioning                  = true

  retention_policy = {
    is_locked             = var.lock_retention
    retention_period_days = var.retention_days
  }

  lifecycle_rules = [
    {
      action = { type = "Delete" }
      condition = {
        age        = var.retention_days
        with_state = "ANY"
      }
    }
  ]
}

########################
# Optional per-subsidiary Data Access audit logging
# (Inline because the official log-export module doesn't cover this.)
########################

resource "google_project_iam_audit_config" "all_services" {
  for_each = var.enable_data_access_audit ? var.subsidiaries : {}

  project = each.value.project_id
  service = "allServices"

  audit_log_config {
    log_type = "ADMIN_READ"
  }
  audit_log_config {
    log_type = "DATA_READ"
  }
  audit_log_config {
    log_type = "DATA_WRITE"
  }
}
