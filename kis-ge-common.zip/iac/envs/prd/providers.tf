provider "google" {
  region = var.region_primary

  # When running locally with user ADC, force the Google client library to send
  # x-goog-user-project so APIs like Discovery Engine + DLP route quota/billing
  # to the resource's project instead of a default consumer project. The
  # explicit `billing_project` is necessary because some resources (DLP de-id,
  # DLP inspect, …) only carry a `parent` argument; the provider does not
  # parse a project out of the parent string.
  user_project_override = true
  billing_project       = var.billing_project
}

provider "google-beta" {
  region                = var.region_primary
  user_project_override = true
  billing_project       = var.billing_project
}
