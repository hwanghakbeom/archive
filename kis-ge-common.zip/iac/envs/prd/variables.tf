variable "org_id" {
  description = "KRInvest GCP organization ID (numeric). Reserved for future org-scoped resources."
  type        = string
}

variable "region_primary" {
  description = "Primary GCP region for regional resources (e.g. asia-northeast3 for Seoul)."
  type        = string
  default     = "asia-northeast3"
}

variable "billing_project" {
  description = <<-EOT
    Project used to attribute billing / quota for every Google API call this
    Terraform makes. Set together with provider `user_project_override = true`.
    Required because some resources (DLP de-id/inspect templates, etc.) only
    carry a `parent` argument with no explicit `project`, so the provider
    cannot auto-derive a user_project header and falls back to a default
    consumer project that does not have the API enabled.

    Pick a project that has every API used by this stack enabled (typically
    the first/only subsidiary host project). For single-subsidiary, set this
    equal to subsidiaries[<key>].project_id.
  EOT
  type        = string
}

variable "retention_days" {
  description = "Audit log retention duration. 2555 = 7 years."
  type        = number
  default     = 2555
}

variable "lock_retention" {
  description = "Lock the audit bucket retention policy (IRREVERSIBLE). Flip to true only after sign-off."
  type        = bool
  default     = false
}

variable "enable_data_access_audit" {
  description = "Enable DATA_READ/DATA_WRITE audit logging on allServices (per-subsidiary). Staged per-service rollout recommended."
  type        = bool
  default     = false
}

###################################################################
# VPC Service Controls (Rows 7 / 16 / 26)
# All resources are gated on enable_vpc_sc. Defaults: feature OFF +
# DRY_RUN ON when enabled. Apply requires roles/accesscontextmanager.policyAdmin
# at the organisation level (snswang@mz.co.kr currently lacks this).
###################################################################
variable "enable_vpc_sc" {
  description = <<-EOT
    Master toggle for the VPC-SC stack (Access Policy + Access Level +
    Service Perimeter). DEFAULT FALSE so Terraform never tries to call
    Access Context Manager APIs unless explicitly enabled. Requires
    `roles/accesscontextmanager.policyAdmin` at the org level on the
    applying identity.
  EOT
  type        = bool
  default     = false
}

variable "vpc_sc_dry_run" {
  description = <<-EOT
    When true, the Service Perimeter is created in dry-run mode —
    violations are logged but NOT blocked. Recommended for the first
    1–2 weeks; review violations in Cloud Logging, then flip to
    false for enforcement. Setting false on a perimeter that has
    never been dry-run is a recipe for self-inflicted outages.
  EOT
  type        = bool
  default     = true
}

variable "vpc_sc_access_policy_id" {
  description = <<-EOT
    Numeric ID of a pre-existing Access Context Manager policy for the
    org (e.g., "123456789"). If null and enable_vpc_sc = true,
    Terraform creates a new policy. There can only be ONE access
    policy per organisation — set this if one already exists, or
    leave null to let Terraform manage it.
  EOT
  type        = string
  default     = null
}

variable "vpc_sc_allowed_ip_ranges" {
  description = <<-EOT
    Corporate IP/CIDR ranges that are allowed through the perimeter
    Access Level (e.g., KIS office + VPN ranges). Empty list = no IP
    condition (members-only access). Format: CIDR strings like
    "203.0.113.0/24".
  EOT
  type        = list(string)
  default     = []
}

variable "vpc_sc_allowed_members" {
  description = <<-EOT
    Identities that bypass the perimeter Access Level conditions —
    typically the Terraform applier + emergency-access groups.
    Format: "user:foo@bar.com" or "group:admins@bar.com" or
    "serviceAccount:tf@project.iam.gserviceaccount.com".
    Defaults to the current applier (`snswang@mz.co.kr`) so the
    perimeter doesn't lock out future terraform runs.
  EOT
  type        = list(string)
  default     = ["user:snswang@mz.co.kr"]
}

variable "vpc_sc_ingress_identities" {
  description = <<-EOT
    Identities that are admitted into the perimeter for all restricted
    services from any source. This is a direct ingress-rule bypass
    that is more reliable than relying on the access level alone —
    Cloud Console / gcloud / Web UI sessions sometimes fail the access
    level's `members:` check even when the user IS in the member list
    (the access-level membership signal is weaker than an explicit
    ingress identity).

    Use sparingly — every identity here can call any restricted
    service from anywhere. Pattern: include the human ops accounts +
    emergency-access SAs only. Defaults to the current applier so
    BigQuery/Cloud Storage/etc. don't break in the Console after a
    fresh perimeter apply.
  EOT
  type        = list(string)
  default     = ["user:snswang@mz.co.kr"]
}

variable "vpc_sc_ingress_source_projects" {
  description = <<-EOT
    Project NUMBERS (not IDs) outside the perimeter that should be
    admitted as ingress sources. Required to bridge `RESOURCES_NOT_IN_SAME_SERVICE_PERIMETER`
    violations when a call's quota/billing project (x-goog-user-project)
    sits outside the perimeter but targets a resource inside.

    Concrete case: `kis-common-gcp` (project number 207734967960) holds
    the Terraform state bucket and is intentionally OUTSIDE the
    perimeter. When a Console/CLI session has its quota project pinned
    to `kis-common-gcp` and queries BQ in `kis-gemini-enterprise`,
    perimeter sees source ≠ target and denies — `access_level = "*"`
    alone does NOT bridge a project-to-project crossing.

    Each entry is rendered as `sources.resource = "projects/<NUMBER>"`
    inside the same ingress_from block as the identity allowlist.
  EOT
  type        = list(string)
  default     = []
}

variable "vpc_sc_restricted_services" {
  description = <<-EOT
    Google APIs to restrict inside the perimeter. Calls to these
    APIs from outside the perimeter (or from identities not in the
    access level) are denied (or logged, in dry-run mode).
  EOT
  type        = list(string)
  default = [
    #"discoveryengine.googleapis.com",
    "aiplatform.googleapis.com",
    "storage.googleapis.com",
    "bigquery.googleapis.com",
    "dlp.googleapis.com",
    "cloudkms.googleapis.com",
  ]
}

variable "reasoning_engine_query_qpm" {
  description = <<-EOT
    Per-project per-region per-minute ceiling on Vertex AI Reasoning
    Engine (Agent Engine) query requests
    (`aiplatform.googleapis.com/reasoning_engine_service_query_requests`).

    GCP platform default = 90/min/project/region. Like Row 9, consumer
    overrides on rate-limit metrics are typically capped at the
    platform default (tighten-only). 90 = explicit pin; lower to
    tighten abuse protection on Agent inference (Row 44).

    The override is applied at `var.region_primary` only. If an Agent
    workload runs in a different region, add a separate override or
    parameterise this further.

    Reference points (sustained):
      90/min = 1.5 QPS — platform default
      30/min = 0.5 QPS — strict; suitable for low-traffic internal agent
      10/min = ~6s between calls — paranoid abuse ceiling
  EOT
  type        = number
  default     = 90

  validation {
    condition     = var.reasoning_engine_query_qpm >= 0 && var.reasoning_engine_query_qpm <= 90
    error_message = "reasoning_engine_query_qpm must be between 0 and 90 (consumer override platform constraint mirrors the Row 9 pattern; raise via a quota increase request to Google)."
  }
}

variable "discoveryengine_conversational_qpm" {
  description = <<-EOT
    Per-project per-minute ceiling on Discovery Engine conversational
    search read requests (`discoveryengine.googleapis.com/conversational_search_read_requests`).

    GCP platform default = 600/min/project. The consumer override can
    only set values in the range **0–600** (overrides can only TIGHTEN
    the limit; raising it requires a quota increase request to Google).

    Default here = 600 (explicit pin at platform default — documents
    the ceiling in IaC, no runtime change). Lower → stricter abuse
    protection. Reference points:
      600/min = ~10 QPS sustained, ~60 active chat users
      300/min =  ~5 QPS sustained, ~30 active chat users
      100/min = ~1.7 QPS sustained, ~10 active chat users
  EOT
  type        = number
  default     = 600

  validation {
    condition     = var.discoveryengine_conversational_qpm >= 0 && var.discoveryengine_conversational_qpm <= 600
    error_message = "discoveryengine_conversational_qpm must be between 0 and 600 (consumer override platform constraint)."
  }
}

variable "gemini_widget_fqdn" {
  description = "Gemini Enterprise backend FQDN reached via Internet NEG."
  type        = string
  default     = "vertexaisearch.cloud.google.com"
}

variable "subsidiaries" {
  description = "Subsidiaries to onboard. project_id must already exist (created out-of-band). Identity is Google Workspace (GSUITE) only. Add one entry per subsidiary."
  type = map(object({
    display_name            = string
    project_id              = string
    gemini_admin_members    = list(string)
    gemini_end_user_members = list(string)
    company_name            = string

    # External LB (only when expose_via_lb = true)
    expose_via_lb      = optional(bool, false)
    custom_domain      = optional(string)
    gemini_app_id      = optional(string)
    gemini_app_path    = optional(string, "/test-app")
    cloud_armor_policy = optional(string)
  }))
  default = {}

  validation {
    condition = alltrue([
      for k, v in var.subsidiaries :
      !try(v.expose_via_lb, false) || (v.custom_domain != null && v.gemini_app_id != null)
    ])
    error_message = "When expose_via_lb = true, both custom_domain and gemini_app_id must be set."
  }
}
