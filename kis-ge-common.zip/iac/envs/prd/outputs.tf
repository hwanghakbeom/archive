########################
# Per-subsidiary audit log sinks (terraform-google-modules/log-export)
########################

output "audit_log_sinks" {
  description = "Per-subsidiary audit log sink, destination bucket, and writer identity."
  value = {
    for k, v in var.subsidiaries : k => {
      project_id      = v.project_id
      bucket_name     = module.audit_storage[k].resource_name
      destination_uri = module.audit_storage[k].destination_uri
      writer_identity = module.audit_log_export[k].writer_identity
    }
  }
}

output "retention_policy_locked" {
  description = "Whether the audit bucket retention policy is locked (applies to every subsidiary's bucket)."
  value       = var.lock_retention
}

########################
# Gemini Enterprise (per subsidiary)
########################

output "gemini_enterprise_endpoints" {
  description = "Per-subsidiary Gemini Enterprise data store and search engine names + widget config IDs."
  value = {
    for k, _ in var.subsidiaries : k => {
      data_store_name    = google_discovery_engine_data_store.gemini[k].name
      search_engine_name = google_discovery_engine_search_engine.gemini[k].name
      widget_config_id   = google_discovery_engine_widget_config.gemini[k].config_id
    }
  }
}

########################
# External LB (per opt-in subsidiary)
########################

output "external_lb_endpoints" {
  description = "Per-subsidiary LB anycast IP + custom domain. Use to publish DNS A records."
  value = {
    for k, v in local.lb_subsidiaries : k => {
      lb_ip              = google_compute_global_address.lb[k].address
      dns_target         = v.custom_domain
      managed_cert_name  = google_compute_managed_ssl_certificate.lb[k].name
      user_facing_url    = "https://${v.custom_domain}${try(v.gemini_app_path, "/test-app")}"
      backend_target_url = "https://${var.gemini_widget_fqdn}/home/cid/${v.gemini_app_id}"
    }
  }
}
