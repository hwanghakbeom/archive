# Google Cloud Security Command Center (SCC) 서비스 티어 비교표

> **출처**: https://docs.cloud.google.com/security-command-center/docs/service-tiers  
> **작성일**: 2026-05-13  
> 스프레드시트 붙여넣기용 (탭 구분 테이블)

---

## 티어 개요

| 티어 | 설명 | 적용 범위 | 활성화 수준 |
|------|------|-----------|-------------|
| **Standard-legacy** | 기본 보안 및 컴플라이언스 포스처 관리 (구 Standard) | Google Cloud 전용 | 조직 수준 |
| **Standard** | 기본 보안 및 컴플라이언스 포스처 관리 | Google Cloud 전용 | 조직 수준 |
| **Premium** | Standard 포함 + 고급 보안·컴플라이언스, 공격 경로, 위협 탐지, 컴플라이언스 모니터링 | Google Cloud 전용 | 프로젝트 또는 조직 수준 |
| **Enterprise** | 멀티클라우드 CNAPP 보안 (GCP + AWS + Azure) | GCP·AWS·Azure | 조직 수준 전용 |

> **요금**: Standard는 무료 / Premium·Enterprise는 별도 과금 구조

---

## 기능 비교표 (스프레드시트 붙여넣기용)

> 범례:  
> ✓ = 포함  
> △ = 제한적 포함 (일부 기능만)  
> ✗ = 미포함  
> (조직) = 조직 수준 활성화 필요  
> (기본비활성) = 별도 활성화 필요  
> (별도요금) = 추가 요금 발생  
> (Preview) = 미리보기 기능

---

### 1. 취약점 탐지 (Vulnerability Detection)

| 기능 | Standard-legacy | Standard | Premium | Enterprise | 기능 설명 |
|------|:-:|:-:|:-:|:-:|------|
| **취약점 스캐닝** | | | | | |
| 이상 탐지 (Anomaly Detection) | ✓(조직) | ✓(조직) | ✓(조직) | ✗ | 프로젝트 및 VM 인스턴스에서 자격증명 유출, 크립토마이닝 등 보안 이상 징후를 식별 |
| Artifact Registry 취약점 평가 | ✓ | ✓ | ✓ | ✓ | Artifact Registry 스캔을 통해 특정 자산에 배포된 취약한 컨테이너 이미지 발견 사항을 SCC에 자동 기록 |
| 민감 데이터 보호 검색 (Sensitive Data Protection) | ✓(기본비활성) | ✗ | ✓(기본비활성) | ✗ | 민감 데이터를 발견·분류하고 보호를 지원. 별도 요금 적용 |
| Google Cloud 취약점 평가 (Preview) | ✗ | △(제한) | ✓(조직) | ✓ | 에이전트 설치 없이 Compute Engine VM 인스턴스의 중요·고위험 소프트웨어 취약점 발견 |
| Agent Platform 취약점 평가 (Preview) | ✗ | ✗ | ✓ | ✓ | Agent Platform 취약점 평가 스캔 결과를 SCC에 자동 기록하여 에이전트 워크로드 취약점 탐지 |
| Notebook 보안 스캐너 (Preview) | ✗ | ✗ | ✓ | ✓ | Colab Enterprise 노트북에서 사용되는 Python 패키지의 취약점 탐지 및 해결 |
| VM Manager 취약점 보고서 (Preview) | ✗ | ✗ | ✓(조직) | ✗ | VM Manager 활성화 시 취약점 보고서를 SCC에 자동 기록. 별도 요금 적용 |
| AWS 취약점 평가 | ✗ | ✗ | ✗ | ✓ | EC2 인스턴스에 설치된 소프트웨어 및 ECR(Elastic Container Registry) 이미지의 취약점 탐지 |
| **Security Health Analytics** | | | | | |
| 관리형 취약점 평가 스캔 (Google Cloud) | ✗ | △(제한) | ✓ | ✓ | Google Cloud 자산에서 가장 심각한 취약점과 잘못된 구성을 자동 감지하는 관리형 스캔 서비스 |
| 컴플라이언스 모니터링 | ✗ | ✗ | ✓ | ✓ | Security Health Analytics 탐지기를 NIST, HIPAA, PCI-DSS, CIS 등 주요 보안 벤치마크 컨트롤에 매핑 |
| 커스텀 모듈 지원 | ✗ | ✗ | ✓ | ✓ | 사용자가 직접 Security Health Analytics 탐지기를 작성하여 커스텀 취약점 탐지 규칙 생성 |
| **웹 보안 스캐너 (Web Security Scanner)** | | | | | |
| 커스텀 스캔 | ✓ | ✓ | ✓ | ✓ | 방화벽 외부에 배포된 GCE·GKE·App Engine 공개 웹 애플리케이션에 대해 커스텀 스캔을 예약·실행 |
| 추가 OWASP Top 10 탐지기 | ✗ | ✗ | ✓ | ✓ | OWASP Top 10 기준의 추가적인 웹 애플리케이션 취약점 탐지기 제공 |
| 관리형 스캔 | ✗ | ✗ | ✓ | ✓ | SCC가 구성하고 관리하는 주간 자동 스캔으로 공개 웹 엔드포인트의 취약점을 정기 점검 |

---

### 2. 가상 레드팀 / 위험 평가 (Virtual Red Teaming / Risk Assessment)

| 기능 | Standard-legacy | Standard | Premium | Enterprise | 기능 설명 |
|------|:-:|:-:|:-:|:-:|------|
| 공격 경로 시뮬레이션 (Attack Path Simulations) | ✗ | ✗ | ✓(조직) | ✓ | 잠재적 공격자가 고가치 리소스에 도달하기 위해 사용할 수 있는 경로를 식별하여 취약점·잘못된 구성 발견 사항의 우선순위를 지원 |
| 초크포인트 (Chokepoints) | ✗ | ✗ | ✗ | ✓ | 여러 공격 경로가 수렴하는 리소스 또는 리소스 그룹을 식별 |
| 이슈 (Issues) | ✗ | ✗ | ✓(조직) | ✓ | 가상 레드팀 및 보안 그래프 기반 규칙 탐지를 통해 클라우드 환경에서 가장 중요한 보안 위험을 식별 |
| 리스크 리포트 (Preview) | ✗ | ✗ | ✓(조직) | ✓ | 공격 경로 시뮬레이션 결과를 포함한 리포트. 고수준 개요, 독성 조합 샘플, 관련 공격 경로 제공 |
| 독성 조합 (Toxic Combinations) | ✗ | ✗ | ✗ | ✓ | 특정 패턴으로 함께 발생할 때 고가치 리소스로 이어지는 공격 경로를 형성하는 복합 위험 그룹을 탐지 |
| **기타 취약점 서비스** | | | | | |
| GKE 보안 포스처 대시보드 (Preview) | ✓ | ✓ | ✓ | ✓ | Kubernetes 워크로드 보안 잘못된 구성, 실행 가능한 보안 공지, 컨테이너 OS 및 언어 패키지 취약점 조회 |
| Model Armor | △ | △ | ✓ | ✓ | LLM 프롬프트 및 응답에 대한 보안·안전 위험 스크리닝. 기본 토큰은 무료 제공, SCC 발견 사항 연동은 Premium/Enterprise 전용 |
| Mandiant CVE 평가 (Preview) | ✗ | △(제한) | ✓ | ✓ | Mandiant 위협 인텔리전스 분석가의 CVE 평가로 발견 사항을 보강. CVE 악용 가능성 및 잠재적 영향도 포함, CVE ID 기반 쿼리 지원 |
| Mandiant 공격 표면 관리 | ✗ | ✗ | ✗ | ✓ | 환경 전반에 걸쳐 인터넷 연결 자산을 검색·분석하고 외부 생태계를 지속 모니터링하여 악용 가능한 노출 탐지 |

---

### 3. 포스처 및 정책 관리 (Postures & Policies)

| 기능 | Standard-legacy | Standard | Premium | Enterprise | 기능 설명 |
|------|:-:|:-:|:-:|:-:|------|
| Binary Authorization | ✓(조직) | ✓(조직) | ✓(조직) | ✗ | 컨테이너 기반 애플리케이션 개발·배포 시 소프트웨어 공급망 보안 조치 구현. 컨테이너 이미지 배포 모니터링 및 제한. 별도 요금 적용 |
| CIEM (Cloud Infrastructure Entitlement Management) | ✗ | ✗ | ✗ | ✓ | 잘못 구성되었거나, 과도한 권한 또는 민감한 권한이 부여된 주체(ID) 계정을 식별 |
| Cyber Insurance Hub | ✓(조직) | ✓(조직) | ✓(조직) | ✗ | 조직의 기술 리스크 포스처를 프로파일링하고 보고서를 생성. 별도 요금 적용 |
| IaC(Infrastructure as Code) 유효성 검사 | ✓(조직) | ✗ | ✓(조직) | ✗ | 조직 정책 및 Security Health Analytics 탐지기 기준으로 IaC 코드를 배포 전 검증 |
| Policy Controller | ✓(조직) | ✓(조직) | ✓(조직) | ✗ | Kubernetes 클러스터에 대한 프로그래밍 가능 정책의 적용 및 시행을 지원. 별도 요금 적용 |
| Policy Intelligence | △ | △ | ✓ | ✓ | 액세스 정책 이해·관리 및 보안 구성 개선을 위한 도구 제공. 기본 기능 무료, 고급 기능은 Premium/Enterprise 전용 |
| 컴플라이언스 매니저 (Compliance Manager) | ✗ | △(제한,조직) | ✓(조직) | ✓ | Google Cloud 환경의 보안·컴플라이언스 의무 이행을 위한 컨트롤·프레임워크 정의·배포·모니터링·감사 |
| 데이터 보안 포스처 관리 (DSPM) | ✗ | △(제한,조직) | ✓(조직) | ✗ | 민감 데이터의 액세스 및 사용을 관리하기 위한 데이터 보안 프레임워크 및 클라우드 컨트롤 평가·배포·감사 |
| AI Protection | ✗ | ✗ | ✓(조직) | ✓ | AI 워크로드 보안 포스처 관리, 위협 탐지, AI 자산 인벤토리에 대한 리스크 완화 지원 |
| 보안 포스처 (Security Posture) | ✗ | ✗ | ✓(조직) | ✓ | Google Cloud 리소스의 보안 상태 정의·배포·모니터링. 포스처 드리프트 및 무단 변경 감지. Enterprise는 AWS 환경도 지원 |

---

### 4. 위협 탐지 및 대응 (Threat Detection & Response)

| 기능 | Standard-legacy | Standard | Premium | Enterprise | 기능 설명 |
|------|:-:|:-:|:-:|:-:|------|
| Google Cloud Armor | ✓(조직) | ✓(조직) | ✓(조직) | ✗ | DDoS 공격, XSS(크로스 사이트 스크립팅), SQLi(SQL 인젝션) 등 위협으로부터 Google Cloud 배포를 보호. 별도 요금 적용 |
| 민감 작업 서비스 (Sensitive Actions Service) | ✗ | ✗ | ✓ | ✓ | 악의적인 행위자가 수행할 경우 비즈니스에 해를 끼칠 수 있는 작업이 조직·폴더·프로젝트에서 발생할 때 탐지 |
| Agent Platform 위협 탐지 (Preview) | ✗ | ✗ | ✗ | ✓ | Agent Platform에 배포되고 관리되는 에이전트에 대한 런타임 공격을 탐지 |
| Container 위협 탐지 | ✗ | ✗ | ✓ | ✓ | GKE 컨테이너를 대상으로 하는 런타임 공격 탐지 |
| Cloud Run 위협 탐지 | ✗ | ✗ | ✓ | ✓ | Cloud Run 컨테이너를 대상으로 하는 런타임 공격 탐지 |
| Event 위협 탐지 (Event Threat Detection) | ✗ | ✗ | ✓ | ✓ | Cloud Logging 스트림을 분석하여 이벤트 로그 기반 위협 탐지. 커스텀 모듈 생성 지원 |
| VM 위협 탐지 (Virtual Machine Threat Detection) | ✗ | ✗ | ✓ | ✓ | VM 인스턴스에 대한 위협 탐지. Enterprise 티어에서는 AWS EC2 지원 포함 |
| 상관 위협 탐지 (Correlated Threats) | ✗ | ✗ | ✓ | ✓ | 개별 탐지 결과 간의 상관관계를 분석하여 복합적인 위협 패턴을 식별 |
| Google SecOps SOAR 통합 | ✗ | ✗ | ✗ | ✓ | Google Security Operations과 통합하여 보안 오케스트레이션·자동화·대응(SOAR) 기능 제공 |
| **대응 (Response)** | | | | | |
| 티케팅 시스템 연동 (Jira, ServiceNow 등) | ✗ | ✗ | ✗ | ✓ | Jira, ServiceNow 등 외부 티케팅 시스템과 연동하여 발견 사항 기반 티켓 자동 생성 및 추적 |
| 플레이북 기반 자동 대응 (SOAR Playbook) | ✗ | ✗ | ✗ | ✓ | SOAR 플레이북을 통해 보안 인시던트에 대한 대응 워크플로를 자동화 |

---

### 5. 멀티클라우드 지원 (Multi-cloud Support)

| 기능 | Standard-legacy | Standard | Premium | Enterprise | 기능 설명 |
|------|:-:|:-:|:-:|:-:|------|
| Google Cloud | ✓ | ✓ | ✓ | ✓ | Google Cloud 환경의 리소스·설정·로그 수집 및 보안 분석 |
| AWS (Amazon Web Services) | ✗ | ✗ | ✗ | ✓ | AWS 환경 연결을 통해 구성·리소스 데이터 수집 및 로그 기반 위협 탐지 지원 |
| Azure (Microsoft Azure) | ✗ | ✗ | ✗ | ✓ | Azure 환경 연결을 통해 구성·리소스 데이터 수집 및 보안 분석 지원 |

---

### 6. 일반 기능 (General Features)

| 기능 | Standard-legacy | Standard | Premium | Enterprise | 기능 설명 |
|------|:-:|:-:|:-:|:-:|------|
| Google Cloud Console 통합 | ✓ | ✓ | ✓ | ✓ | Google Cloud 콘솔 내 Security Command Center 전용 대시보드에서 발견 사항 및 자산 확인 |
| Gemini AI 기반 보안 | ✗ | ✗ | ✓ | ✓ | Gemini AI를 활용한 보안 인사이트, 발견 사항 분석 및 대응 가이드 제공 |
| Pub/Sub 발견 사항 알림 | ✓ | ✓ | ✓ | ✓ | 보안 발견 사항 발생 시 Pub/Sub를 통해 실시간 알림 전송 |
| BigQuery 내보내기 | ✓ | ✓ | ✓ | ✓ | 발견 사항을 BigQuery로 스트리밍 또는 일괄 내보내기하여 심층 분석 가능 |
| Cloud Logging 내보내기 | ✓ | ✓ | ✓ | ✓ | 보안 로그를 Cloud Logging으로 내보내기하여 통합 로그 관리 |
| 보안 마크 (Security Marks) | ✓ | ✓ | ✓ | ✓ | 발견 사항 및 자산에 사용자 정의 주석(태그)을 추가하여 분류 및 필터링 지원 |
| 발견 사항 음소거 (Mute Findings) | ✓ | ✓ | ✓ | ✓ | 정적 또는 동적 음소거 규칙을 사용하여 특정 발견 사항을 숨기고 노이즈 감소 |
| CMEK (고객 관리 암호화 키) 지원 | ✗ | ✗ | ✓ | △ | 고객이 관리하는 암호화 키(CMEK)를 사용하여 SCC 데이터 암호화. Enterprise 일부 기능 미지원 |
| 데이터 레지던시 (Data Residency) 지원 | ✗ | ✗ | ✓ | △ | 데이터가 특정 지역 내에서만 처리·저장되도록 지원. Enterprise 일부 기능 미지원 |
| 프로젝트 수준 활성화 | ✗ | ✓ | ✓ | ✗ | 조직 전체가 아닌 개별 프로젝트 단위로 SCC 활성화 가능 |
| 조직 수준 활성화 | ✓ | ✓ | ✓ | ✓ | 조직 전체에 SCC를 한 번에 활성화하여 모든 프로젝트·폴더 통합 관리 |
| **요금** | 무료 | 무료 | 종량제/구독 | 별도 | Standard-legacy·Standard는 추가 비용 없음. Premium은 종량제 또는 구독 방식 선택. Enterprise는 별도 계약 |

---

## 티어 선택 가이드

| 시나리오 | 권장 티어 |
|---------|-----------|
| Google Cloud 기본 보안 모니터링만 필요 | **Standard** |
| GCP 고급 위협 탐지 + 컴플라이언스 필요 | **Premium** |
| AWS/Azure 포함 멀티클라우드 통합 보안 운영 | **Enterprise** |
| 보안 운영 센터(SOC) 기능 + 자동화된 대응 필요 | **Enterprise** |

---

## 주석 설명

| 주석 | 의미 |
|------|------|
| (조직) | 조직 수준 활성화 필요 (프로젝트 수준 활성화 시 미지원) |
| (기본비활성) | 기능이 포함되어 있으나 기본적으로 활성화되어 있지 않음 (별도 활성화 필요) |
| (별도요금) | 해당 서비스는 SCC 티어 요금과 별도로 추가 요금 발생 |
| (제한) | 일부 기능만 제공 (전체 기능은 상위 티어에서 지원) |
| (Preview) | 미리보기 단계 기능으로 정식 출시 전 |
| CMEK △ | Enterprise 티어에서 일부 기능은 CMEK 미지원 |
| DRZ △ | Enterprise 티어에서 일부 기능은 데이터 레지던시 미지원 |

---

*참고: 위 표는 공식 문서를 기준으로 정리된 내용이며, 최신 정보는 항상 [Google Cloud 공식 문서](https://docs.cloud.google.com/security-command-center/docs/service-tiers)를 참조하시기 바랍니다.*
