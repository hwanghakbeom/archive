# Gemini Enterprise 사전 테스트 실행 가이드

[**문서 목적	2**](#문서-목적)

[**전체 구조	2**](#전체-구조)

[**테스트 A. 맞춤 도메인 연결 사전 테스트	3**](#테스트-a.-맞춤-도메인-연결-사전-테스트)

[A-1. 목적	3](#a-1.-목적)

[A-2. 사전 준비사항	3](#a-2.-사전-준비사항)

[A-3. 입력값 확인	3](#a-3.-입력값-확인)

[A-4. 권장 테스트 방식	4](#a-4.-권장-테스트-방식)

[A-5. 구성 절차	4](#a-5.-구성-절차)

[1\. API 활성화	4](#1.-api-활성화)

[2\. 전역 외부 IP 생성	4](#2.-전역-외부-ip-생성)

[3\. Internet NEG 생성	5](#3.-internet-neg-생성)

[4\. Backend Service 생성	5](#4.-backend-service-생성)

[5\. Host 헤더 처리 확인	5](#5.-host-헤더-처리-확인)

[6\. 인증서 생성	6](#6.-인증서-생성)

[7\. URL Map 구성	6](#7.-url-map-구성)

[8\. Target Proxy 및 Forwarding Rule 생성	7](#8.-target-proxy-및-forwarding-rule-생성)

[9\. 테스트 도메인 연결	7](#9.-테스트-도메인-연결)

[A-6. 테스트 수행	7](#a-6.-테스트-수행)

[A-7. 예상 결과	8](#a-7.-예상-결과)

[A-8. 성공 기준	8](#a-8.-성공-기준)

[A-9. 자주 발생하는 이슈	8](#a-9.-자주-발생하는-이슈)

[1\. 404 응답	8](#1.-404-응답)

[2\. 502 또는 503 응답	8](#2.-502-또는-503-응답)

[3\. TLS 연결 문제 또는 빈 응답	9](#3.-tls-연결-문제-또는-빈-응답)

[4\. 로그인은 되지만 원래 앱이 열리지 않는 경우	9](#4.-로그인은-되지만-원래-앱이-열리지-않는-경우)

[**테스트 B. 앱 액세스 제어 사전 테스트	9**](#테스트-b.-앱-액세스-제어-사전-테스트)

[**B-1. 읽기 전용 점검	9**](#b-1.-읽기-전용-점검)

[B-1 목적	9](#b-1-목적)

[B-1 수행 원칙	9](#b-1-수행-원칙)

[B-1 확인 항목	9](#b-1-확인-항목)

[B-1 수행 절차	10](#b-1-수행-절차)

[1\. 현재 실행 계정 확인	10](#1.-현재-실행-계정-확인)

[2\. 프로젝트 IAM 정책 읽기 전용 조회	10](#2.-프로젝트-iam-정책-읽기-전용-조회)

[3\. 현재 계정에 부여된 직접 역할 확인	10](#3.-현재-계정에-부여된-직접-역할-확인)

[4\. 원본 URL과 맞춤 도메인 URL 비교	10](#4.-원본-url과-맞춤-도메인-url-비교)

[B-1 예상 결과	11](#b-1-예상-결과)

[B-1 성공 기준	11](#b-1-성공-기준)

[**B-2. 테스트 사용자 기반 실제 검증	11**](#b-2.-테스트-사용자-기반-실제-검증)

[B-2 목적	11](#b-2-목적)

[B-2 사전 준비사항	11](#b-2-사전-준비사항)

[B-2 권장 절차	11](#b-2-권장-절차)

[B-2 예상 결과	11](#b-2-예상-결과)

[B-2 성공 기준	12](#b-2-성공-기준)

[**보안 해석	12**](#보안-해석)

[**운영 전환 전 권장 확인사항	12**](#운영-전환-전-권장-확인사항)

[**테스트 성공 영상	12**](#테스트-성공-영상)

[**최종 요약	12**](#최종-요약)

## **문서 목적** {#문서-목적}

본 문서는 고객 환경에서 Gemini Enterprise에 대해 두 가지 사전 테스트를 직접 수행할 수 있도록 작성한 실행 가이드입니다.

이번 가이드는 아래 두 개의 독립된 테스트를 구분해서 설명합니다.

1. 테스트 A. 맞춤 도메인 연결 사전 테스트  
2. 테스트 B. 앱 액세스 제어 사전 테스트

두 테스트는 목적과 검증 범위가 서로 다르므로 분리해서 수행하는 것이 적절합니다.

## **전체 구조** {#전체-구조}

| 테스트 항목 | 목적 | 실제 변경 여부 | 준비사항 |
| :---- | :---- | :---- | :---- |
| 테스트 A. 맞춤 도메인 연결 사전 테스트 | 맞춤 도메인 진입 및 로그인 흐름 검증 | 테스트용 인프라 구성 필요 | 앱 URL, 프로젝트 권한, 도메인, 인증서 |
| 테스트 B-1. 앱 액세스 제어 읽기 전용 점검 | 현재 권한 구조와 검증 가능성 확인 | 변경 없음 | 운영 계정 |
| 테스트 B-2. 앱 액세스 제어 실제 검증 | 앱 수준 차등 접근 효과 검증 | IAM 정책 적용 필요 | 테스트 사용자 또는 그룹 |

## **테스트 A. 맞춤 도메인 연결 사전 테스트** {#테스트-a.-맞춤-도메인-연결-사전-테스트}

### A-1. 목적 {#a-1.-목적}

Gemini Enterprise 웹 애플리케이션을 고객 지정 도메인 또는 고객 지정 도메인 경로로 연결할 수 있는지 확인합니다.

### A-2. 사전 준비사항 {#a-2.-사전-준비사항}

- Google Cloud 프로젝트  
- Gemini Enterprise 웹 애플리케이션 URL 1개  
- Load Balancer, External IP, Certificate, DNS 리소스를 생성할 수 있는 권한  
- 테스트용 도메인  
  - 빠른 테스트: `nip.io`  
  - 운영 검토: 고객 소유 도메인  
- SSL 인증서  
  - 빠른 테스트: self-signed certificate  
  - 운영 검토: [Google-managed certificate](https://docs.cloud.google.com/load-balancing/docs/ssl-certificates/google-managed-certs?hl=ko) 또는 고객 관리 인증서

### A-3. 입력값 확인 {#a-3.-입력값-확인}

테스트 대상 Gemini Enterprise 웹 애플리케이션 URL을 확인합니다.

예시:

```
https://vertexaisearch.cloud.google.com/home/cid/APP_ID
```

또는:

```
https://vertexaisearch.cloud.google.com/home/cid/APP_ID?hl=ko
```

확인해야 하는 값은 아래 두 가지입니다.

- Host: `vertexaisearch.cloud.google.com`  
- Path: `/home/cid/APP_ID`

일반적으로 아래 위치에서 확인합니다.

1. Google Cloud Console 접속  
2. AI Applications 페이지 이동  
3. 대상 Gemini Enterprise 애플리케이션 선택  
4. Integration 또는 Web App 항목에서 URL 확인

### A-4. 권장 테스트 방식 {#a-4.-권장-테스트-방식}

가장 단순한 사전 테스트 방식은 아래와 같습니다.

- 테스트 도메인: `https://agentspace.<EXTERNAL_IP>.nip.io/test-app`  
- 실제 연결 대상: `https://vertexaisearch.cloud.google.com/home/cid/APP_ID`

### A-5. 구성 절차 {#a-5.-구성-절차}

#### 1\. API 활성화 {#1.-api-활성화}

아래 API가 활성화되어 있는지 확인합니다.

- [Compute Engine API](https://console.cloud.google.com/apis/library/compute.googleapis.com)  
- [Cloud DNS API](https://console.cloud.google.com/apis/library/dns.googleapis.com)

Cloud Shell 에 접속합니다.   
\[참고\] [Cloud Shell 사용하기](https://docs.cloud.google.com/shell/docs/using-cloud-shell?hl=ko)  
\[참고\] [Cloud Shell 실습하기](https://www.skills.google/focuses/563?catalog_rank=%7B%22rank%22%3A1%2C%22num_filters%22%3A0%2C%22has_search%22%3Atrue%7D&parent=catalog&search_id=81719827)  
![][image1]

#### 2\. 전역 외부 IP 생성 {#2.-전역-외부-ip-생성}

[https://docs.cloud.google.com/vpc/docs/reserve-static-external-ip-address?hl=ko\#reserve\_new\_static](https://docs.cloud.google.com/vpc/docs/reserve-static-external-ip-address?hl=ko#reserve_new_static)   
예시:

```shell
gcloud compute addresses create custom-ip \
  --global \
  --ip-version=IPV4
```

확인:

```shell
gcloud compute addresses describe custom-ip \
  --global \
  --format='value(address)'
```

#### 3\. Internet NEG 생성 {#3.-internet-neg-생성}

[https://docs.cloud.google.com/load-balancing/docs/internal/setting-up-internal-zonal-neg\#create\_gce\_vm\_ip\_zonal\_negs](https://docs.cloud.google.com/load-balancing/docs/internal/setting-up-internal-zonal-neg#create_gce_vm_ip_zonal_negs) 

예시:

```shell
gcloud compute network-endpoint-groups create GE-INEG \
  --network-endpoint-type=internet-fqdn-port \
  --global

gcloud compute network-endpoint-groups update GE-INEG \
  --add-endpoint="fqdn=vertexaisearch.cloud.google.com,port=443" \
  --global
```

#### 4\. Backend Service 생성 {#4.-backend-service-생성}

[https://docs.cloud.google.com/load-balancing/docs/network/transition-to-backend-services?hl=ko\#configure\_the\_backend\_service](https://docs.cloud.google.com/load-balancing/docs/network/transition-to-backend-services?hl=ko#configure_the_backend_service)   
예시:

```shell
gcloud compute backend-services create GE-BES \
  --load-balancing-scheme=EXTERNAL_MANAGED \
  --protocol=HTTPS \
  --global

gcloud compute backend-services add-backend GE-BES \
  --network-endpoint-group=GE-INEG \
  --global-network-endpoint-group \
  --global
```

#### 5\. Host 헤더 처리 확인 {#5.-host-헤더-처리-확인}

환경에 따라 `urlRewrite.hostRewrite`만으로는 기대대로 동작하지 않을 수 있습니다.

이 경우 Backend Service에 명시적으로 Host 헤더를 추가해 검증할 수 있습니다.

예시:

```shell
gcloud compute backend-services update GE-BES \
  --global \
  --custom-request-header='Host:vertexaisearch.cloud.google.com'
```

이 단계는 환경에 따라 필요하지 않을 수 있지만, 실제 사전 테스트에서는 이 설정이 적용된 뒤 정상 응답을 확인했습니다. 고객 환경에서도 함께 검증하는 것을 권장합니다.

#### 6\. 인증서 생성 {#6.-인증서-생성}

빠른 테스트의 경우 self-signed certificate를 사용할 수 있습니다.

예시 개념:

- Common Name: `agentspace.<EXTERNAL_IP>.nip.io`  
- Subject Alternative Name: `agentspace.<EXTERNAL_IP>.nip.io`

등록 예시:

```shell
gcloud compute ssl-certificates create GE-CERT \
  --certificate=cert.pem \
  --private-key=private-key.pem \
  --global
```

#### 7\. URL Map 구성 {#7.-url-map-구성}

핵심 개념:

- 입력 경로: `/test-app`  
- 재작성 경로: `/home/cid/APP_ID`  
- 재작성 대상 host: `vertexaisearch.cloud.google.com`

예시 개념:

```
hostRules:
- hosts:
  - agentspace.<EXTERNAL_IP>.nip.io
  pathMatcher: ge-matcher

pathMatchers:
- name: ge-matcher
  defaultService: BACKEND_SERVICE
  routeRules:
  - priority: 1
    matchRules:
    - prefixMatch: /test-app
    routeAction:
      weightedBackendServices:
      - backendService: BACKEND_SERVICE
        weight: 100
      urlRewrite:
        hostRewrite: vertexaisearch.cloud.google.com
        pathPrefixRewrite: /home/cid/APP_ID
```

#### 8\. Target Proxy 및 Forwarding Rule 생성 {#8.-target-proxy-및-forwarding-rule-생성}

예시:

```shell
gcloud compute target-https-proxies create GE-HTTPS-PROXY \
  --ssl-certificates=GE-CERT \
  --url-map=GE-URL-MAP \
  --global

gcloud compute forwarding-rules create GE-FR \
  --load-balancing-scheme=EXTERNAL_MANAGED \
  --address=CUSTOM-IP \
  --target-https-proxy=GE-HTTPS-PROXY \
  --global \
  --ports=443
```

#### 9\. 테스트 도메인 연결 {#9.-테스트-도메인-연결}

빠른 사전 테스트의 경우 `nip.io`를 사용할 수 있습니다.

예시:

```
agentspace.<EXTERNAL_IP>.nip.io
```

운영용 검토에서는 고객 소유 도메인의 A 레코드를 Load Balancer 외부 IP로 연결합니다.

### A-6. 테스트 수행 {#a-6.-테스트-수행}

브라우저에서 아래 주소로 접속합니다.

```
https://agentspace.<EXTERNAL_IP>.nip.io/test-app
```

빠른 확인을 위해 `curl`을 사용할 수도 있습니다.

```shell
curl -kI https://agentspace.<EXTERNAL_IP>.nip.io/test-app
```

### A-7. 예상 결과 {#a-7.-예상-결과}

성공적인 경우 아래 흐름을 기대할 수 있습니다.

1. 맞춤 도메인 URL 접속  
2. self-signed certificate 사용 시 브라우저 경고 표시  
3. 경고 허용 후 Google 로그인 페이지 이동  
4. 로그인 후 원래 Gemini Enterprise 애플리케이션 연결

`curl` 기준 기대 결과:

- `302`  
- `Location` 헤더가 `accounts.google.com` 로그인 URL을 가리킴  
- `continue` 파라미터가 원래 Gemini Enterprise 앱 URL을 가리킴

### A-8. 성공 기준 {#a-8.-성공-기준}

- 맞춤 도메인 URL이 유효하게 응답합니다.  
- 로그인 페이지로 정상 이동합니다.  
- 로그인 이후 원래 Gemini Enterprise 애플리케이션으로 연결됩니다.  
- 맞춤 도메인이 원래 앱의 인증 흐름을 그대로 따름을 확인합니다.

### A-9. 자주 발생하는 이슈 {#a-9.-자주-발생하는-이슈}

#### 1\. 404 응답 {#1.-404-응답}

- `pathPrefixRewrite` 경로가 정확한지 확인합니다.  
- `APP_ID`가 실제 대상 애플리케이션과 일치하는지 확인합니다.  
- URL Map 경로 규칙이 올바르게 등록됐는지 확인합니다.

#### 2\. 502 또는 503 응답 {#2.-502-또는-503-응답}

- Internet NEG가 정상 생성됐는지 확인합니다.  
- Backend Service와 NEG 연결이 정상인지 확인합니다.  
- 외부 백엔드 호스트와 포트가 정확한지 확인합니다.

#### 3\. TLS 연결 문제 또는 빈 응답 {#3.-tls-연결-문제-또는-빈-응답}

- 인증서와 도메인 이름이 일치하는지 확인합니다.  
- Load Balancer 전파가 완료됐는지 확인합니다.  
- 필요 시 Backend Service에 `Host` 헤더를 명시적으로 강제해 확인합니다.

#### 4\. 로그인은 되지만 원래 앱이 열리지 않는 경우 {#4.-로그인은-되지만-원래-앱이-열리지-않는-경우}

- 원래 앱 URL이 정확한지 확인합니다.  
- 로그인한 계정이 해당 애플리케이션 권한을 보유했는지 확인합니다.  
- 조직 로그인 정책이나 추가 인증 정책이 있는지 확인합니다.

## **테스트 B. 앱 액세스 제어 사전 테스트** {#테스트-b.-앱-액세스-제어-사전-테스트}

## **B-1. 읽기 전용 점검** {#b-1.-읽기-전용-점검}

### B-1 목적 {#b-1-목적}

운영 계정의 권한을 변경하지 않고 현재 권한 구조와 검증 가능성을 확인합니다.

### B-1 수행 원칙 {#b-1-수행-원칙}

- IAM 정책 변경 없음  
- 운영 계정 권한 변경 없음  
- 라이선스 변경 없음  
- 읽기 전용 조회만 수행

### B-1 확인 항목 {#b-1-확인-항목}

아래 항목을 점검합니다.

1. 현재 실행 계정이 어떤 프로젝트 수준 역할을 보유하는지 확인합니다.  
2. 현재 계정이 이미 Discovery Engine 관련 넓은 권한을 갖고 있는지 확인합니다.  
3. 원본 Gemini Enterprise 앱 URL과 맞춤 도메인 URL이 동일한 인증 흐름을 따르는지 확인합니다.  
4. 현재 계정만으로 앱 수준 액세스 제어 효과를 검증할 수 있는지 판단합니다.

### B-1 수행 절차 {#b-1-수행-절차}

#### 1\. 현재 실행 계정 확인 {#1.-현재-실행-계정-확인}

```shell
gcloud auth list
gcloud config list
```

#### 2\. 프로젝트 IAM 정책 읽기 전용 조회 {#2.-프로젝트-iam-정책-읽기-전용-조회}

아래 역할을 중심으로 확인합니다.

- `roles/discoveryengine.agentspaceAdmin (Gemini Enterprise Admin)`  
- `roles/discoveryengine.agentspaceUser (Gemini Enterprise User)`  
- `roles/discoveryengine.agentspaceRestrictedUser (Gemini Enterprise Restricted UserBeta)`  
- `roles/discoveryengine.user  (Discovery Engine User)`

예시:

```shell
gcloud projects get-iam-policy PROJECT_ID --format=json
```

참고 : [GCP Project ID 확인하기](https://docs.google.com/presentation/d/1JPxy92Azzq5E_KGh4O8Zhuygt7YNR4auu2Rvcjmorr8/edit?slide=id.g3d885de96fd_1_0#slide=id.g3d885de96fd_1_0)

#### 3\. 현재 계정에 부여된 직접 역할 확인 {#3.-현재-계정에-부여된-직접-역할-확인}

예시:

```shell
gcloud projects get-iam-policy PROJECT_ID \
  --flatten='bindings[].members' \
  --format='table(bindings.role,bindings.members)' \
  --filter='bindings.members:user:USER_EMAIL'
```

#### 

#### 4\. 원본 URL과 맞춤 도메인 URL 비교 {#4.-원본-url과-맞춤-도메인-url-비교}

예시:

```shell
curl -kI https://agentspace.<EXTERNAL_IP>.nip.io/test-app
curl -kI 'https://vertexaisearch.cloud.google.com/home/cid/APP_ID'
```

### B-1 예상 결과 {#b-1-예상-결과}

읽기 전용 점검을 통해 아래 중 하나를 확인합니다.

- 현재 계정이 프로젝트 수준 broad role을 이미 보유하고 있어 앱 제한 효과를 직접 검증하기 어렵습니다.  
- 또는 현재 계정이 앱 수준 검증에 사용할 수 있는 상태입니다.

이번 사전 테스트에서는 첫 번째 경우를 확인했습니다. 따라서 기능 존재와 구성 가능성은 확인했지만 실제 차등 효과는 검증하지 않았습니다.

### B-1 성공 기준 {#b-1-성공-기준}

- 현재 계정 권한을 변경하지 않았습니다.  
- 현재 계정의 접근 근거를 설명할 수 있습니다.  
- 맞춤 도메인 URL과 원본 URL이 동일한 인증 흐름을 따른다는 점을 확인합니다.  
- 앱 액세스 제어 실제 검증을 위해 추가로 무엇이 필요한지 정리합니다.

## **B-2. 테스트 사용자 기반 실제 검증** {#b-2.-테스트-사용자-기반-실제-검증}

### B-2 목적 {#b-2-목적}

앱 수준 IAM 정책이 실제로 사용자별 차등 접근을 만드는지 검증합니다.

### B-2 사전 준비사항 {#b-2-사전-준비사항}

- 테스트용 사용자 계정 1개  
- 또는 테스트용 그룹과 실제 로그인 가능한 사용자 1개  
- 테스트 사용자에 대한 라이선스 부여 계획  
- 테스트 범위와 영향 범위에 대한 사전 합의

### B-2 권장 절차 {#b-2-권장-절차}

1. 현재 운영 계정은 그대로 유지합니다.  
2. 테스트 사용자에게 필요한 최소 라이선스를 부여합니다.  
3. 프로젝트 수준 broad role은 운영 정책에 맞게 검토합니다.  
4. 앱 수준 IAM 정책으로 특정 사용자 또는 그룹에 접근 권한을 부여합니다.  
5. 원본 앱 URL과 맞춤 도메인 URL 모두로 접속해 차등 결과를 확인합니다.

### B-2 예상 결과 {#b-2-예상-결과}

- 허용 사용자: 로그인 후 대상 앱에 접근 가능  
- 비허용 사용자: 로그인은 가능하더라도 대상 앱 접근 불가  
- 맞춤 도메인 URL: 원본 앱과 동일한 권한 결과를 보여야 함

### B-2 성공 기준 {#b-2-성공-기준}

- 앱 수준 IAM 정책에 따라 접근 차등이 발생합니다.  
- 맞춤 도메인 URL도 동일한 차등 결과를 보여줍니다.  
- 맞춤 도메인이 권한 우회를 만들지 않음을 확인합니다.

## **보안 해석** {#보안-해석}

두 테스트를 종합하면 아래와 같이 해석하는 것이 적절합니다.

- 맞춤 도메인 진입점은 별도의 접근 경로를 제공합니다.  
- 그러나 실제 애플리케이션 접근은 원래 Gemini Enterprise의 인증 및 권한 정책을 따릅니다.  
- 앱 액세스 제어 기능은 지원됩니다.  
- 다만 운영 계정이 이미 프로젝트 수준 broad role을 갖고 있으면, 그 계정만으로는 앱 수준 제한 효과를 검증하기 어렵습니다.

## **운영 전환 전 권장 확인사항** {#운영-전환-전-권장-확인사항}

- 고객 소유 도메인 적용  
- 운영용 인증서 적용  
- 조직 정책 기반 접근 통제 적용  
- 필요 시 WIF 또는 추가 인증 정책 반영  
- 사용자 경험 검증  
- 운영 로그 및 모니터링 체계 검토  
- 테스트 사용자 기반 앱 액세스 제어 2차 검증 수행

## **테스트 성공 영상** {#테스트-성공-영상}

[\[MZS\] GE 커스텀 도메인 구성 테스트 성공 영상(GE\_커스텀\_도메인).mov](https://drive.google.com/file/d/1ehesjgVU8vzCzgmBlFGVy7ASI3Nl0ut1/view?usp=drive_link) 

## **최종 요약** {#최종-요약}

본 가이드를 통해 고객은 아래 두 가지를 분리해서 검증할 수 있습니다.

- 맞춤 도메인 연결 가능 여부  
- 앱 액세스 제어 구성 가능 여부

그리고 앱 액세스 제어는 아래 두 단계로 나누어 검증하는 것이 적절합니다.

- 1차: 운영 계정 무변경 읽기 전용 점검  
- 2차: 테스트 사용자 기반 실제 차등 검증

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAnAAAACHCAYAAACWG2QrAAAmFklEQVR4Xu2diXsURd7H9095dUXdRd0VddfVVzllAV2PVwTUBTkFEeUWOeWSI9zIjdz3nXAIyCUBwn3JkXAkJCQQjoQjkIS7Xn4Vq6n+dddcmclMp7+f5/k83V1V3dOT6Zr+TnXP5E8CAAAAAAB4ij/xAgAAAAAAL1FaWipu3rwpbjz21q1b4u7du7xJpQMBzkfs2LVHDBgyAlag9DcPxLSZcx3rQAhhojh42KiEDUMqsAWT2lVGEOB8wtnMc7wIVBAjx07gRZJjJ9JF0a3bEEIf6wVKSksTKsTRaBsPaaFI61UmEOAAiDEPHjzgRRL+Rg4h9J9egUbiEgEeyiKxsoAAB0Cc4G/kEEL/6RXocmq84UGsPFYGEOAAiBP8jRxC6D+9QrwDXKSXTU1WhsupCR/gjmffF/3mFYmPBxeKJaklvDrq3HmQONf5QeWGv5FDCP2nV4h3gOMBLBpGQnrGKV4UNxI6wFFoczNWFN0pEk0WNuXFQWneqp1NvTxaJKesFcOSRvPiqEOPQ4LYw9/IIYT+MxjVvtxvc+qaC7xJhRCNABfpOcz0bVN+7g0kX5eM5NuptK1Yh7jklNDOwWEHONrxUC0PprBGI3KxIpIAx19M+sOr4Oa1AKf2XQliC38jj8Q58xY6ysrr1YJCh7yNLh0rvMzNocNHiS3btlvLR38/7pCvs3f/QZG6M80hb8c9dvyko4w8eOiInOr7XFB4zdFu0JAkRxmEsTAQKrTxsjYjM2xlocC3o/ig9+9y+tuR66zGTjQCXKTnFh689ADHy9wM1C5U9HNjpM8jFNS2Q8lQYQc4/gRMljdsuIW3WBNugKPnmZxiTsrRfIHpccr7Nw0Gfw2BnVdfe50XlQv+Rh5M/bVRZW4BLjMr21Gmb4OXcanN/IVLLEePnWCrX7JspaM93wY57qdJlmvXbZDt9ABH81y+je969hV79x1wqLe5dv2G6NS1h1Tty7ET9gCnytP27LMt83myQ8euMtQdPXbCVg5hLAyEW+iiETi3ch19xG7AnHNWmc66PQW28lgHuOSUJwME4cJDVyjBLNR2oULboOdAlOe5BCOc7YYd4CoCutct1AB3vm8nkfFRDUudom21bOrol2TVPXY8wJm2qwj2R9brKXypF0YdBLwNX1btSUrjsQ5w+kGp9iOcg4nzQ/+BvKjSsH7DRl4UNvyNPFRv3Cyy5nmAo8DVo1c/xzpKei15GZe32blrt2158dIVAdvrLl+ZbGvHQ1rvfgPldNqM2Y51SQpwvCyQPwwcIhYtWS6mTJthK1f7SAHu55lzrOXde/c7tvHb9p22dSCMpSYCBTVTOWfcilxxu/SBGLH4vG2dC1fviLajykZ4qLzDuNMxDXB0/tLPLeGcU+j353joCiWYhdoulN+3o/WTU5yDNeE8j1iQkAFOBSodfh8chbyCxbNt4UoPWzy06cv88qxa1gMcbYfCIcEfRxHsxVP19MLrbWleDY/ybahlfsDQcqwDHKFf/g6nw7340stizNhxokqV5+XyrFmzxf889Yy4d++enCr0ecVTT1cRo8eMterS09NF/QbviaXLlltlNO3b9wfx2j9eF4cPH9FXFytWrBTfduwkOnXqIubOnWe1X6atf+rUKfF/H38ihg4b7roPzVu0klPaFrFz1y5RtepLYs6cubZ9IOi5NWr8admK5YC/kQezRet2lqpMD3AbN20Vu9L2ipzcPDFx8jTH+vQa0rRNuw6OOt2kUWMd6vXtv+ksrt+w33/Ct6EcNGS4nKp2eoDTR/mUfP1z2eflj1BzeTv1GGpev4Q6Y9Y8OUp36PBRxwgc3/fBQ59cOsUIHKwITZQ3wM379ZJoPeLJpVZ9HZqv3+OouP/gUcxH4PTBC24o0L/F4qErlGAWajvafjBM+0rloVzqDIdwBmvCDnD8BTAZ6g64Qfe58QCnowKcHrIUeoDj6AFOx20ETm1HhUL+OITpRVWoerd2pjpTeXJK7C+hcvhrGoiaNetY81lZWXKqRuB4gKMfth08eIgMU3Xr1rfV6VMiMzPTUUbzW7Zuk9vYlZZmlV9/fJJ224YOtXnhhb/JeVqfJNwC3MOHD+W82zbjMQLHR9v0sq86dLLKKFzRtFuP3nI6fMQYMXmqfUTq287dRc75XMf2fpo4VfTqO8BV1Wbg4GHyeFDL+jyX6lQApHkV4PixpavW3bf/4OPn1dlV/W/Rr/9gsWLVatvjqgAnA19WWeCjy6LBAlzrtvZwG8r9dhCWx0C4BbVAwU5B9SV3yt6/9DLis8EnrLI5G/NjEuCSU8oGLcLRFIR44DIFM5qnqwO8DW/nZjBofTeonJ5rNAn299AJO8BVFOrSphsqgLkFq2gGOLL4+GFbWx3Ti6pQ9W7t3OrUMDMvJ+ggqYgApw4e9VhqORiNGjXhRcYAp1Ot2mvWvFtQUgTaxsvVXhX375d9uUWvy8vLs5Zbtmwtwxvxyiv/sNooVIBbvHiJnCZigKPLgsdPpMsQokar3ELdpctXHWXhePpMppwOGDzMUUfHgppv2aa9o0xXrU9fTti4aYtsp4/ArUxeI6VyNc+3QdLzpjY08kj30vF6ctmKZOtYVer1Xbr3dEjleruL+ZfEzaJbtvX2HTjkeCwIo2kg6MsKFLDUN0/VcrAAR6h2uooxy3LFv7sfsbn7ROAgE06A0wk0ApecEjz8mL6B6hbMaNktxPF2uqF8E5XWdyPU5xAOtD3T43ESNsAR/FIn/z04ClfBLqE+uF52uc10CVWN9pkCHMEfR4e/gPofX035C6Kvw8v1dfXAxpdjgXp8fT9CRYWbUaNGi+ListenYcPGckrhiDpJTs55R/gqKCgQHb7pKOdV3ZChw8Sp06dtZWpKI28jRtj/pcvTf35WPHr0SCxYsNDRvmmz5nJar14Dcfv2bZGWttuxDwRfL1iAS0oaac1HCn8jj0QV4CZMmmo5dvwka/7y1QJHcOEhZtac+bZt0mtP0/xLlx2P56Zqzy+1cqmdHuDUesofh41wrMNHxNzWIynA6cumb6Hybejb4tvdtXuvYz0Io20w1IibHsJ4IHOD1/NlTjRH4DjluQcu0A/40nb0ebWs5lWY09txQ/lBX9P+UnlySnQDXDiEHeD4i2AyWmFDhSsl/xkRdX+aHrgU0fwSQ7CROF29XEEvsqrXX3C9nODrK8O5Lh4peieL5KAsLLSPbOqfbC5cCPzbRXRZlQerjIwn92+oOtP/Fc3Pz+dF4vTpM7blYJ+0Ll68yIuMhNPWBH8jj0S3EbhwXbEqxbbMj2eSr8Pb61OT4ydOcQQ4Ll+HbNH6K6uevmmqf4lDGWwEjqvq6R47uuRM+0VfbnBrA2EsjZRgIY6PvgVqS8QywBHJKfZzXTjw0MUDHAU1feRNLR84dNjWzs1gqP2mKZfK6bxM89EinL9R2AGuMqKP6oGKpbi4WDxT5TlRvXot0bVbd15twcNdZYC/kcdDtzDkN/UvhSjpZ0jcfh8OwmhbHkIJZtGivAGOCCec6PDQxQNcMAO1C4ba52BGi3C258sAp36mRI28qcupAFQk/I0cQug/vUI0AlykV5FM98HxEGWSvl3O1yWDXZXh6PfzJQK+DHAKFeIAiAf8jRxC6D+9QjQCXHng4SsaRkJySvQul5YXXwc4AOIJfyOHEPpPrxDvABfoywyRGMqXFxIdBDgA4gR/I4cQ+k+vEO8AR/AQVh4rAwhwAMSY7PO5vEjC38ghhP7TK0ybOZcXxQUexCKxsoAA5xOSRv/Ei0AFkXHK/nMmiuGjxzvezCGE/jLRefDwoTh2Ip0Xx5VIL6dWhsumOghwAAAAAPAcpm+ncsP9tqlXQIADAAAAgKeh0TUV6Ogf1N+9e5c3qXQgwAEAAAAAeAwEOAAAAAAAj/Gnu/fuCwghhBBC6B0R4CCEEEIIPSYCHIQQQgihx0SAgxBCCH3uWzVqwwRy2/ZUx2vERYCDEEIIfS4PEDD+8teIiwAHIYQQ+lweHmD85a8RFwEOQggh9Lk8PJhs1qK1oyyQTT5v5ijTDbY9Vf/pf7+wlV++Uiil+Y6du9nqPmrY2JrPOJ1pzQ8dPlKq1tfXIb/q0NFRZjLYfofiFy3bOMp0+WvERYCDEEIIfS4PD2SPnn3EpCnTRf9BQ8SsOfNlmVvwCeS+A4dty7R+48+aWtsJtj1Vf+Tocaus/TedxNffdhbfPd6/rx/P8wC3aMlyOa1Ru644dSZLzk+cPM2m2+PStmh66XKB+Orrb8WefQflNlR9vXfft+bd1g/FzHPnxRePw18oz5+/RlwEOAghhNDn8vDAwwUPcIuXrpDzY8dPlMsnM87Y6pevTJHzGafO2raZsuYXOX27Zh2rfVZ2ru2xaD7/0lXb9vQAR9auW19OU3ekyQCnQtv0GbNF2u59Vjt9BI62dTYz27Zd5W/bd1rzFFzVvD6aR+vowYvMu3BJLlPgo+UVq1bLZXqetLz1tx3W+tVrvSM+b9ZCztf5dwM5VaHRTf4acRHgIIQQQp/LwwPJQ45eNixplJwuWbZSTnmAW7f+V9dtUHChMhW49PqmzVvZlinkuQW4bj16iV59+8vHWLNugzUCR6FRBcPxE6fIqQpwKjiSdeu/J7f749Akq0x/3Ab/+VBOl61IFjNnz7PK3UbgUnfullMVDJNXr7PV8+ffpm17Wdap63dWWf33PrC1UfLXiIsAByGEEPpcHh54+Dh+8pStrPMfAWT8hMlyygPcnHkLHdtQo05k40//66hv0epLR+BxC3CqXJfXbdy0Vfx+PF2MHDP+yfZbt3Vs122ZLrGq+WMnMqx5twCnRtjocqu+PQqWfLt06VfNq5E6stY79WzrKvlrxC13gFuddk1OX/oyw1a+Yf91a77Jj+es+Tajc2ztDp25LbpMzrOWLxaUOtTbx9rmrdpJ9WU1T7/Lwj1zNsuxjVh6NitbtPyyvZTXrX18wJBqWd93CCGE0CQPDyTdq0b3sG3eul2OHFGZCiQX86+IpFFjxbmcPKucLrOq+gsXL4sJk6a6BqUx4yZY5Xo9BTj6csD6jZvF/oNHbPU8wJ3NyhGr1663VOXTfp5la3f6j3vgaMSwd9/+4vOmzR2PSy5dvsqa37otVY7mbdu+U/TrP8jWbmXyGtv6KsAdOvy77fm6BTi1rLfr2bufrV6XchX5xrenHa/XjPVXIwtwtbqdEalHb0pNAU5f1gMcb7f10A3xVuczxvqKVIU3JYUlU5iLhzw8kvmXLjvaKeO9vxBCCL0hDw+JbtLIMTb1Uaz3P2ooRo0ZL7p919OxnnKCNsqmHDl6nKMs1uZfLnCUKWt0PWNTf70oK0UU4Br0OmvNRxLg9NG1VTuvJUyAK7p1WwweOkKsWbvBCj807dzte2ue6nXpGjnfTqyl/dh34JCt7GrhtccHwmUxf9ESOa/a8XUhhBBCLg8PfvSdeu86ymLpfz782FGm23Firlj6W6Ho+fMF22t15+590X/uxegEuOLSe7bgNWxxvi208QCnb8ttBG7m+qs29faxVo2+UYhTy25tjp1Id5TH2qXLVln7s2ffATm/a/ceq17tO81funzFdd8hhBBCLg8PMP7qr8/qtLLb0hZvKxTv9s6U8+UKcKV3nSNwpXfui9e+PmUr0wOcsukwZ1m8VQGozVffiqSRY8WBg4dF67YdZN2WbdvltW83aeSOb6uipf0uLim7X7B126+tMt4OQggh5PLwAONvl8m5MkfRVKler2bDsyMLcAdO3RI5l8rCAg9wjQY5b+oPNcDdLrlnlLeNlf0HDrGph6DTZ7Pk8oDBQ0WvPv3jFpAGDhnuKCP5/vTpN9DRBkIIIeTSPdU8QMD4SZmKy1+ziAKcLg9wbqoAV1R8T1y9ccdVugzL14uHX7bvKH8IUFfV8YBUUnpHLFi8zLGNWBtqgIMQQghh7NQDVtqJIkd9IFfsuGaNsvE6XsaXI/4WamV2aNJoh3p96s5dYuTon8TEydNF3sV8x/oV4cw58xxlZEHhdYe8DYQQQgjLb3nC2xdJ2bblXw/cELe0q43T1111qLfvO+sCAhyEEEIIYbhGGt6iJQIchBBCCKHHRICDEEIIIfSYCHAQQgghhB4TAQ5CCCGE0GMiwEEIIYQQekwEOAghhBBCj4kAByGEEELoMRHgIIQQQgg9JgIchBBCCKHH/BP/Z6mVRf5EIYQQQggrixiBgxBCCCH0mAhwEEIIIYQeEwEOQgghhNBjIsBBCCGEEHpMBDgIIYQQQo+JAAchhBBC6DER4CCEEEIIPSYCHIQQQgihx0SAgxBCCCH0mAhwEEIIIYQeEwEOQgghhNBjIsBBCCGEEHpMBDgIIYQQQo+JAAchhBBC6DER4CCEEEIIPWbUAlzuhUvizNlsCH1lVnaeuF1S6ugP4Yr+A/3o2cwccbXguqM/hCv1H9oW3z6EldlyB7jsnDwBgN+5WnDN0TdCEf0HgDJuFZc4+kcg3+pXE0JfW64Al3/pKu+DAPiWcEMc+g8AdngfCSQ/mUHoN8sV4AAAds6dy3X0E5MAADvoPwCEDgIcAFHknks/MQkAsIP+A0DoIMABEGV4PzEJAHDC+4lJAPwOAhwAUYb3E5MAACe8n5gEwO8gwAEQZXg/MQkAcML7iUkA/A4CHABRhvcTkwAAJ7yfmATA7yDAARBleD8xCQBwwvuJSQD8DgIcAFGG9xOTAAAnvJ+YBMDvIMABEGV4PzEJAHDC+4lJAPwOAhwAUYb3E5MAACe8n5gEwO/EPMAlp6wVzVu1swSgssP7iclImT1nPi8CoNLA+4lJAPxOzAOcHt7IYUmjeRMAKhW8n5iMlP4DhyDEgUoL7ycmAfA7MQ1wfPQtkUfhsnNyxK60NFG9ei1eVW4uXboskpNTrOXLl69otU+4ceMGLwIehPcTkwAAJ7yfmAwXGjzgAn/Ttt1XtuXJk6faljkTJkyU01/WbxD/89QzrLbiiWmA48GtvCGO/mAmFTdv3hSLFi12+P33vUR+fr5sc/Jkuvjll/VyPZpu3rzFNcCdPZsp3qlbTzRu8plDN9Rj0XbVPMEDnOmFb9euPS8CcSA941TExyjB+4nJSFD7Fun+5edfMh5/kXLixEljfwyX8qwLEoNE7D/8/BPpueiNN96Sx2jVqi/J6Rtvvs2bRI1w+wKFC94PCwoKZF242wrEDz8MEKdOnbKVtfmyne1xe/fpK8s/+6ypePjwoa0tJz093bZc3veQcOCPM2XKNNuy/pzmz19YIQEunP4T0wBHn3B4Z9F3zFQeCP5H48smUlavtgKcQq37TJXnpG4Bbt26X6zlUNH3iQ7sZl+0cAQ4eiPgIsAlBup4jPQTOu8nJsOF95dw+o2Cjr3klNVi5szZvCpiKMANHDSYFwOfkmj9R78SVB6e/vOzIiMjw1aWmrrDthxNQj23ESNGjBItW7bmxSItbbechrOtYJgCXFFRkbVcpcrz4s6dOyEFOH3f6OpUw4aNtdrYQo9N718KGoFbuXKVlHj//Y+sOqIiAlw4/SemAY7gJxvViXgZSR0tGB98YP+D1qr9jm05NzdXhrFnn/urQxp9UBQXF4sBAweJDz78P7lsGoH7y19fEC++9LJDE0uWLpPrvfS3alYZRuC8RyidxwTvJybDwdShwz0xqWOPH4PqQwVNybt378pyegN+8OCBVV6t2mu29YhAAa5L1+7Wun+t+qJVPmTIMKv8zJmzjv2ik2VWVpbVZvnyFda6O3ftsspfeeUfVjlIHNyO1VDh/cRkOJj6SKj959GjR3LULRh0SU4dm/UbvGeV0/qqXB3jimB9gaBzmmqjn8cUfJscvd60j3wbNWvVkdPi4hLbvg8fPsIRZHmAa//1N+LAwYO2AFfl2b9Y29i7d58s07fLJejqmFqmUKig5U8/+6/VjqZftn3yvPi23Wjdpq3t703wS6h0BY7e30h6HhUR4IhQ+0/MAxwNB7rdc8DDW6gdaezY8bblefMX2JYpwAUbNcvJOW/98enEQCcLU4ALti0d2pd/vv6GnKdPKPQYJSUlCHAeI5whbDd4PzEZKnrf0C+hqi8yhLqvI0eOliPRBD8GaVkfoVb19Aast6XbB7777ntrmVCXUF//15uWCn3dv7/8ipzSJ3Pqc4pGjZrY3nQJqq9dp67VRpV37tzVts1hw5PE+PETrGUQfxKp/6jRN3Xu4ecadZUo2AmTjrGly5Zby6dOnxZr1qy1JKhv6ZdUGzX+VPzQf6Ccd+tvRCh94c3/fVuOmiv4tkxlOqo+nH1UAY6X07JbgMvOzhbXrl0TM2bOstbRA5y+jr5NfZ4Clbr8qkKvYsOGjXIghqDyTZs2W3W0nJmZKefp9dDXo9C1ePESa5mggZmkpJHWMrUvLS11BDi3EbiFCxeJXr37OP4u0SKc/hPzAOeG6dJqsJ1+u3pNowoKcPSHdfPlaq9qW7NDXyDIy8sTnbt0s8oowPFtKPft26+tXYb6VMHhAY5CnpK2pebpPj0Qf9SxGOxN3QTvJyYDQeGMvm1K6H1D7yOduvawlVF7tY4b+hvO9es3RM2aZW/QvI54/i8vyCm9AdPJSoe3DTQCV6/+u9Y8vWHSp3L65MxHEdQ21VQ/qenlvB8qQeKQCP1HofaFTor6st6P+LIbyx6Ht+7dy/obQcfv4cNHpE89XUWWuR2HVEZBhPoRL2/RolVIfYEf66bHCQTfpo6pjgIc7bv+gYz4/POmrgHu+569xZChw2xBVw9w7773vutz0Of1ANe0WXPH5VfTvvJlCr0Keq/r2LGzVmsmlABHxHIELpz+E/MAp3cYUl0m5eWhdKJw+bhhI3lgmdAPJrcDK1JoGzRS0adPP/Hqa68H3GagOhA/Quk8Jng/MRmMc9k5cqr3DZqqUW094Kn2ah036Fijk5CSlunyiKrjbQl6A966bZtrnSJQgKMRBYUKcHR5ZefOXVor5xtzoABHXzwCiU0i9B8FP7e0bttBBhO3ukDw417Bj10dVVavXgNH+TffdgypL7htlxOsTaBtudXJD3i16sh5/dIlUaNGbdcAp19CVagARwMjc+bMtcr1x9Ln9QD3dYdvxbVr1606wm1f3Zbr1q1vzZsC3K1bt+R6PXr0FBMnTRZvvV3DsR167s89X1WWkxUR4IhQ+0+FBzjVWfRLQaF0IhqyDCZ9kqHhTSVdDqVr/HrZxYsX+aZtqEuofFtuum3L7UUtLCwUkyZPkfNr166zSe15GYgv4Qxhu8H7iclQUSPWhBqZGzt+otiwcZN1iSgYdK8Y/5kaur9DHz1Qxyjd/6aOY34Jle7FWb16jbVMhBvgCP4Gzt+YTQGOLoXo69KJg06CIHFItP6jzi/8pBjulxvmzpvveH+n+7r2Hzgg5+l8wPvKlq3b5DyV0yU6gi718eNfn+d9oVOnLqLOO/+2tXGDyul+VcX27amObQXbRwXN65dQ9e3ScrgBbvr0n63bneh8yB9LoQc4XvfJJ43Fhx997Ch3Ww4lwPF1CLqN6rfftvNii4oIcOH0n5gGOB7QTB0pkSjv78DRPXWvvPpP64A/ffpMzF5oEBvKe5zyfmIyHNxONKqjh/LlH9MxqL/BT506TU5VqCPUpR8qJ6dNm27VKQL9jIgpwNHJTG/Lp6YAR+g3hPfr119rBRKBRO4/ej9y61PB4F9GUCN5iuPHT1h16zdstNWZfnokWF8gBg8eYrW5f9/83NUVH7J9+w5Wub4t0z5S0NH3QwU4gt4TqJwup07/eUbQb6Eq9Euo6ktSdKlV3x+6r52W6QsLPMDRc1X7RN9+Vejruy2HEuDGjB0nRxPVa0i3RfHtcCoiwIXTf+IS4BIZdYIpLzSKcfDgIV4MPEIonccE7ycmw8Xt3lF1b095Mb0ZhfIzAOFCb5j0Zq6gT/N60APeJ9H6j+lH5UP58BNL0BfiD4VEHkiDQb+vxy99R5NQ+09MAxzBO0yiBzgAygvvJyYTiYoMcMQ//vkv65O16bGBP+H9xGRlAX0BRErMAxz/5ANAZYf3E5MAACe8n5gEwO/EPMAB4Dd4PzEJAHDC+4lJAPwOAhwAUYb3E5MAACe8n5gEwO8gwAEQZXg/MQkAcML7iUkA/A4CHABRhvcTkwAAJ7yfmATA7yDAARBleD8xCQBwwvuJSQD8DgIcAFGG9xOTAAAnvJ+YBMDvIMABEGV4PzEJAHDC+4lJAPwOAhwAUYb3E5MAACe8n5gEwO/4MsC9+977YsnSZbw4bPRfzZ4wcZJD4E94PzEJAHDC+4lJAPyOpwIc/XNeroL+Qa/u7NlzrLrs7Gz5z4BpSv+jlIKXHuBoefLkqTY5//tWdbF//37xTJXnrLJA//YkUB2o3PB+YhIA4IT3E5MA+B1PBThi8+YtcrpqVbKtfPv2VJvjxv1kq3+52qvizp07ol79d10D3C+/rLfJ6db9O2v+p58myKke0hDYgIL3E5MAACe8n5gEwO94LsCNGjVaTps2a24rDxSg8vLyZOD729+rGUfggrF12zZr/pNPGsupvt7ixUscAn/C+4lJAIAT3k9MAuB3PBXgXv/Xmw4VFKa4u3fvkXVnz2Za7YjeffqKTZs2W8t8PbdAV716LWs+ZfVqOVXt+D657R/wD7yfmIwHU6ZME00+/dx2/BNFRUXiueerihkzZ8nl+/ft+9evX3/bsmLnzl22vuGGW5/iywAoeD8xWdFs2brNoaJmrTqOc8iVK1eerKxRWFhozWfn5Fjzv/66yZq/cOGCnL73nw+sMsXp02d4kWTBgoVi7tx5lrRMTJ/+s9WmXbv21jxBtxUB7+KpABcKtWq/w4skdOLS1e+fCwUKbXSi0k88fJ4L/AnvJyYrmqpVX7It68foiBGjrHm615MCHJ08jh07LsumTp1m1RNqXbcA9+JLL8vpmTNnxaFDhx0q1Gg6ADq8n5isaPh7+siRT45fCnChsnfvPmteD3AffvSxNb9ly1Y5dQtw3/fszYts/PmZZ23LeoB74cW/azUIcF7HMwGudp26Rhs2bCxHD9wsKCjgm5KoS6i8vW4w9A5drdprWo2zswP/wPuJyYrm5Ml02/Irr/5TPHr0SM7rn/7XrFlrG4FzOzmZAlxubq41r7h48aJ8LA76CHCD9xOTFQ0/XnmA4x/g9+zZq7Uug+7DHj58hMjPzxcLFy4SEyZMtOpeeOFvonGTz6SmAEfbbfDuf2xlOjRyV7dufbF27Tpx8+ZNcf36DVuAo+3p5zYaqaMPWsCbeCbARRt9+DtS1L1wBB/hI4E/4f3EZEVD94Cu37BRPHz4UHTt1l0sX77Cqpv+8wx5cnjr7RpyWQ9w/MR14sRJeS8pwQMcb0snIjppZGZmivoN3rPVPfV0FdsyAATvJyYrGjq2x4wdZ9moURPeJCh/+esLtj4S6gjcnDlzbSNr3bv3EM2+aGEtE7vS0kSrVm3k/MGDh+QX9wgKcCUlJeKNN9+22qpfU8AInLfxbYADIFbwfmIyHqjg1bFjZ1t5cXGJyMrKsqnQTzj37t2Tn/AVPMAlJY205ikkKjY8Do4Eje4patSobc0DoOD9xGS84B9SHjx4IPuPmzrUp7Zt+03Oq2AWaoALF/oprFGjx8h9ow9cChpxHzToRzFg4CBrv4F3QYADIMrwfmIyHpSWlsopHw3jmEbg9IBG6AHO9EUHQgU4HX4iBIDg/cRkvHA7buvVa8CLHPAvDlGY0gOc/uUIdetPuAGObinasWOntUwjbzTqTty+fVvezqCgy6v6BzXgPRDgAIgyvJ+YTGT0AJeaukOrsaMHOLcTWyDCbQ/8Ae8nJhMJCnB0b5vu+fPO+0E5eoBzI9wAR/e06V9UaNr0C3kvnEL/ZQTTF/6Ad0CAAyDK8H5i0ktEO2wlJ6fwIgAkvJ+YBMDvIMABEGV4PzHpZ+jyDQBu8H5iEgC/4+kAt3jJcl7kWbp/38ear0zPy4/wfmISAOCE9xOTAPgdTwW4y5eviL379sv5g4eOiOat2on0jFMiNzfPakPlbqSsWSenJSVlN3HTfQHbtqda9SfTM8Shw0eN9y0kr15rrUvQDairUtZoLYTYsXOXyDrn/Fq2vk+qvqCgUKTt3iuuXLkql+nxVVv1vIA34f3EJADACe8nJgHwO54JcOs3/Cou//GvSSjg6NMFi5Za7VSZjir7cegIGfbOPQ5RR47+bqtTUwpq2dn2G0tVXf+BQ+T0181bRZfuPW11alpQWGiFMYW+TxMmlf0+nCr7+psuctq77wCrjdtzAN6B9xOTAAAnvJ+YBMDveCbAuYWaQAGOpmpehbXrN27IANei9VdWe4W+/c7dvretn51zXrRu28FaptE3mk8aOcZah8rUejNnz7Wt7xbgFi8t+xHVufMXySkCXOWB9xOTAAAnvJ+YBMDvVNoAp7P/wEE5VQGOwhhHX69Hr35ajRAt25QFvi1by36EUXHiRLprSKMAp+MW4FYmr5ZTBLjKB+8nJgEATng/MQmA3/FMgDv6+zGxZ2/Z/W88NGVmnRPbU3eKu3fvuYYfvT0FuJtFRWL+wsWOOmLk6HHidnFx2Yp/0PLL9nKq2syeM19898eXDlq0tq8/eEiSmDJthpxXqLpZj9dDgKv88H5iEgDghPcTkwD4Hc8EOIX6V0AKCmME/ZPgQOTlXRAZGadtP1BaVHTLmqfQpNdx6N42Dt1Lp5Nj+AIEcY7dVxcM9byA9+D9xCQAwAnvJyYB8DueC3CRQOFswqSpAUe2AtUBEA68n5gEADjh/cQkAH7HFwEOgIqE9xOTAAAnvJ+YBMDvIMABEGV4PzEJQKKxfv160bt3b1vZlClTxPTp08Xy5RXzA+O8n5gEwO8gwAEQZXg/MQlAItKvn/1b+IcPH5bTVatW2cpjBe8nJgHwOwhwAEQZ3k9MApCI8ABH/7WGOHLE/b/cRBveT0wC4HcQ4ACIMryfmDRRUFAAYYXoBg9wagRu7dq1tvJYwfuJSQD8DgIcAFGG9xOTACQiKsClppb9r+gFCxaIFStWiDVr7P/7OVbwfmISAL/z/35YmHufEVP2AAAAAElFTkSuQmCC>