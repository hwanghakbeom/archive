# KIS Gemini Enterprise — Security Controls Checklist

Maps the 48 prevent-control scenarios in
[codebase/tf/SCENARIOS.md](../codebase/tf/SCENARIOS.md) to what is
**applied** in `iac/envs/prd/` against the current GCP topology.

## Scope decisions

- **Single-project topology.** All security artifacts (Discovery
  Engine, BigQuery, Cloud Storage, Agent Engine, security/DLP, KMS)
  live in **`kis-gemini-enterprise`**. There is no separate BQ /
  GCS / Agent / security / KMS project. The `codebase/tf/`
  multi-project variables (`var.bq_project_id`,
  `var.gcs_project_id`, etc.) all map to `kis-gemini-enterprise`.
- **SCC Premium / Enterprise: deferred.** Rows 46–49 are out of
  scope for this phase. Revisit after the SCC tier is purchased.
- **Workforce Identity Federation: out of scope.** GE identity is
  Workspace (GSUITE) only.
- **Ops project (`kis-common-gcp`):** TF state + Cloud Build runner
  only. No security resources live here.

## Status legend

- ✅ **Applied** — Terraform code in `iac/envs/prd/` covers this and
  `terraform apply` has been run against `kis-gemini-enterprise`.
- 🟡 **Code-ready, not applied** — Lifted from `codebase/tf/` but
  deferred (no use case yet, or paid feature with nothing to scan).
- 🔴 **Org-level / Workspace-level — blocked** on Cloud Admin (org
  `240369219899`) or Workspace Admin (`koreainvestment.com`).
- ☐ **Console-only** — No Terraform support; manual configuration
  in Workspace Admin Console or SCC Console.
- 🚫 **Out of scope** — Explicitly deferred this phase (SCC, WIF,
  multi-project resources).

Owners:

- **TF** — IaC team (this repo)
- **Cloud Admin** — org-level admin of `240369219899`
- **Workspace Admin** — Workspace tenant admin for `koreainvestment.com`
- **SecOps** — security operations / SOC
- **Finance** — for paid tier / license procurement

---

## 1. Current Terraform state (as of 2026-05-22)

All resources target `kis-gemini-enterprise`. Status markers:

- ✅ **Applied & in state** — `terraform apply` has succeeded.
- 🟡 **Code ready, apply pending** — declared in `iac/envs/prd/`, but
  not yet successfully applied (typically blocked on an operator step
  such as `terraform import` or DNS publication).
- 🟦 **Operator follow-up** — applied, but not yet validated end-to-end
  via the console / a smoke test.

### 1.1 Foundation (audit + GE app)

| Status | Resource | TF address |
|---|---|---|
| ✅ | Project audit-log sink (4 audit-log types) | `module.audit_log_export["kis"]` (`terraform-google-modules/log-export/google ~> 11.1`) |
| ✅ | GCS audit bucket `gs://kis-gemini-enterprise-audit-logs` (retention 2,555d **unlocked**, UBLA, public-access enforced, versioning) | `module.audit_storage["kis"]` (`//modules/storage`) |
| ✅ | 10 base APIs | `google_project_service.gemini[*]` — cloudresourcemanager, serviceusage, discoveryengine, storage, iam, aiplatform, modelarmor, dlp, datacatalog, cloudkms |
| ✅ | Discovery Engine data store (`ge-ds-29118f`) | `google_discovery_engine_data_store.gemini["kis"]` |
| ✅ | Discovery Engine search engine (`ge-engine-29118f`, **`APP_TYPE_INTRANET`**) | `google_discovery_engine_search_engine.gemini["kis"]` |
| ✅ | ACL config (`idp_type = "GSUITE"`) | `google_discovery_engine_acl_config.gemini["kis"]` |
| ✅ | Widget config (`config_id = 2390b20d-fa11-442d-962e-c01a703c6c3d`) | `google_discovery_engine_widget_config.gemini["kis"]` |
| ✅ | IAM module call (`additive`; member lists currently `[]`) | `module.iam_gemini["kis"]` (`terraform-google-modules/iam/google ~> 8.0`) |
| 🟡 | GE Assistant + Model Armor binding (`customer_policy.model_armor_config`; `failure_mode = "FAIL_OPEN"`; `web_grounding_type = "WEB_GROUNDING_TYPE_DISABLED"`) | `google_discovery_engine_assistant.gemini["kis"]` — **GE auto-creates this; needs `terraform import` then `apply`** (one-off per subsidiary; see iac/README §"Onboarding Subsidiary N" step 5) |

### 1.2 Custom-domain LB (opt-in — currently `expose_via_lb = true` for `kis`)

| Status | Resource | TF address |
|---|---|---|
| ✅ | compute API (opt-in only) | `google_project_service.lb_compute["kis"]` |
| ✅ | Static anycast IP | `google_compute_global_address.lb["kis"]` |
| ✅ | Internet FQDN NEG + endpoint (`vertexaisearch.cloud.google.com:443`) | `google_compute_global_network_endpoint{_group,}.lb["kis"]` |
| ✅ | Backend service (host-header rewrite) | `google_compute_backend_service.lb["kis"]` |
| 🟦 | Managed SSL cert — created; will go ACTIVE once DNS A record `kis-gemini.koreainvestment.com → lb_ip` is published (operator step, ~30 min) | `google_compute_managed_ssl_certificate.lb["kis"]` |
| ✅ | URL map (path rewrite `/home/cid/<gemini_app_id>`) | `google_compute_url_map.lb["kis"]` |
| ✅ | Target HTTPS proxy | `google_compute_target_https_proxy.lb["kis"]` |
| ✅ | Global forwarding rule | `google_compute_global_forwarding_rule.lb["kis"]` |

### 1.3 Project-level security controls (`security.tf`)

| Status | Resource | TF address | Scenario |
|---|---|---|---|
| ✅ | KMS keyring + 2 keys (`bq-cmek`, `gcs-cmek`) in `asia-northeast3`. Key-level IAM bindings deferred until workloads consume the keys. | `module.kms_data_keyring["kis"]` (`terraform-google-modules/kms/google ~> 4.0`) | Row 18/25 partial |
| ✅ | Model Armor template — **`us` multi-region** — SDP + PI/Jailbreak + RAI filters. | `google_model_armor_template.user_prompt_sanitize["kis"]` | Rows 3, 5 |
| ✅ | DLP de-identify template — **`us` multi-region** — KOREA_RRN / KOREA_DRIVERS_LICENSE_NUMBER / KOREA_PASSPORT / CREDIT_CARD_NUMBER / EMAIL_ADDRESS character-masked | `google_data_loss_prevention_deidentify_template.ge_response_deid["kis"]` | Row 4 |
| ✅ | DLP inspect template (KR PII + Finance) — **`us` multi-region** — 6 KOREA_* + 5 universal info types | `google_data_loss_prevention_inspect_template.ge_inspect["kis"]` | Row 4, reused by future Discovery Configs |
| ✅ | Data Catalog PII taxonomy (`PII_TAXONOMY`) in `asia-northeast3` | `google_data_catalog_taxonomy.pii_taxonomy["kis"]` | Row 14 |
| ✅ | Policy Tags (`confidential`, `internal`) | `google_data_catalog_policy_tag.pii_*["kis"]` | Row 14 |
| ✅ | Discovery Engine `conversational_search_read_requests` quota override — `1/min/{project}`. Platform allows overrides in range **0–600** (tighten-only); value tunable via `var.discoveryengine_conversational_qpm` (default 600 = pin at platform default) | `google_service_usage_consumer_quota_override.discoveryengine_conversational_per_min["kis"]` | Row 9 |
| ✅ | Vertex AI `reasoning_engine_service_query_requests` quota override — `1/min/{project}/{region}`, regional scope = `var.region_primary`. Tighten-only (allowed 0–90); value tunable via `var.reasoning_engine_query_qpm` (default 90 = pin at platform default). Forward-ready: applies the moment an Agent workload is deployed. | `google_service_usage_consumer_quota_override.reasoning_engine_query_per_min["kis"]` | Row 44 |

### 1.4 Operator follow-ups (no further TF code needed — operations only)

1. **`terraform import` the GE default_assistant**, then `terraform apply`
   to push the Model Armor binding. Exact command in
   [iac/README.md](../iac/README.md) §"Onboarding Subsidiary N" step 5.
2. **Publish DNS A record** `kis-gemini.koreainvestment.com → <lb_ip>`.
   Get `lb_ip` from `terraform output external_lb_endpoints`. Once DNS
   resolves, the managed cert transitions PROVISIONING → ACTIVE in
   ~30 min.
3. **Smoke test the LB path** (per MZ guide §A-7):
   ```sh
   curl -kI https://kis-gemini.koreainvestment.com/test-app
   # expect 302 → accounts.google.com with continue=vertexaisearch.cloud.google.com/home/cid/<gemini_app_id>
   ```
4. **Browser smoke test**: sign in, land on the GE app, send a chat
   query containing a fake `KOREA_RRN` (e.g. `950101-1234567`) — confirm
   the Model Armor + DLP path masks it.
5. **Verify console artifacts** — see §4 below.

### 1.4a VPC-SC runbook (Rows 7 / 16 / 26)

The code is in `iac/envs/prd/vpc-sc.tf`, currently live in **ENFORCE**
(`enable_vpc_sc = true`, `vpc_sc_dry_run = false`) since 2026-05-22.

#### Architecture (as deployed)

- **Restricted services (5):** aiplatform, storage, bigquery, dlp,
  cloudkms. `discoveryengine.googleapis.com` is **excluded** so the
  Gemini Enterprise end-user serving path through the global LB
  (`kis-gemini.koreainvestment.com`) is not blocked in enforce mode —
  end-users do not satisfy the corporate access level.
- **Access level `kis_corporate`:** members = `vpc_sc_allowed_members`
  (default `["user:snswang@mz.co.kr"]`); IP allowlist via
  `vpc_sc_allowed_ip_ranges` (currently empty). OR-combined.
- **Single ingress rule:** identities = `vpc_sc_ingress_identities`
  (default `["user:snswang@mz.co.kr"]`), `sources.access_level = "*"`.
  Belt-and-suspenders alongside the access level (Console/CLI sessions
  sometimes fail the access level's `members:` check).
- **`kis-common-gcp` (ops project hosting Terraform state) is
  intentionally OUTSIDE the perimeter.** If it were inside, perimeter
  violations would break subsequent `terraform apply` runs.

#### Operating contract (required for enforce mode)

- **Human Console / CLI sessions:** pin browser BQ Console quota
  project to `kis-gemini-enterprise` (project picker top-right); pin
  ad-hoc `gcloud` quota project the same way. Without this, calls
  attributed to `kis-common-gcp` targeting in-perimeter resources
  emit `RESOURCES_NOT_IN_SAME_SERVICE_PERIMETER` and are denied.
- **Terraform:** keep ADC quota = `kis-common-gcp` so state reads
  from `gs://kis-common-gcp-tfstate/` stay outside the perimeter
  entirely (source = target = kis-common-gcp). Provider's
  `billing_project = kis-gemini-enterprise` rebills resource ops
  inside the perimeter.

If pinning quota to kis-gemini-enterprise becomes infeasible, add
the kis-common-gcp project number (`207734967960`) to
`vpc_sc_ingress_source_projects` in `terraform.tfvars`. The dynamic
ingress block in `vpc-sc.tf` materialises a second ingress rule
(`sources.resource = "projects/207734967960"`) that bridges the
crossing. Caveat: that ingress rule needs to be in a **separate**
`ingress_policies` block from the `access_level = "*"` one — GCP
rejects combining `access_level = "*"` with `sources.resource` in a
single `ingress_from` (`If IngressSource.access_level is set to '*',
then only 1 IngressSource should be present`). The dynamic blocks
already handle the split correctly.

#### Activation flow (from cold-start)

1. **Cloud Admin** grants `roles/accesscontextmanager.policyAdmin` on
   org `240369219899` to the applying identity. (Already granted to
   `snswang@mz.co.kr` on 2026-05-22.)
2. **IaC team** sets `vpc_sc_allowed_ip_ranges` (KIS corporate + VPN
   CIDRs) and adds emergency-access groups to `vpc_sc_allowed_members`
   in `terraform.tfvars`. Keep the applier in the member list.
3. Flip `enable_vpc_sc = true` (still DRY_RUN). `terraform apply`.
4. **Observe DRY_RUN violations** in Cloud Logging. Narrow to ingress:
   ```
   resource.type="audited_resource"
   protoPayload.metadata.dryRun="true"
   protoPayload.metadata.ingressViolations.servicePerimeter:*
   ```
   Triage each entry: legitimate access pattern → ensure the operating
   contract above is followed (or add to access level / ingress rule
   if structurally required); suspicious → confirms the perimeter is
   working.
5. When ingress violations are clean for the planned operating
   patterns, flip `vpc_sc_dry_run = false` in a dedicated sign-off MR →
   enforcement live. Egress violations (calls FROM inside the
   perimeter TO external projects, e.g. `bigquery-public-data`) are
   acceptable signal-of-design and not a blocker — keep BQ workloads
   inside `kis-gemini-enterprise`.

#### Diagnosing a violation

- `violationReason = NO_MATCHING_ACCESS_LEVEL` → caller is outside the
  corporate access level AND not matched by any ingress rule. Fix:
  add to `vpc_sc_allowed_members` or `vpc_sc_ingress_identities`, or
  pin their session's quota project correctly.
- `violationReason = RESOURCES_NOT_IN_SAME_SERVICE_PERIMETER` →
  cross-perimeter project crossing (e.g. quota project outside,
  target inside). Fix: pin quota project to a project in the same
  perimeter, OR add the source project number to
  `vpc_sc_ingress_source_projects`.
- `violationReason = SERVICE_NOT_ALLOWED_FROM_VPC` → caller is inside
  the perimeter but the call left via a non-allowed egress path.
  Usually means the call hit a non-Google IP. Fix: not common in this
  topology — escalate.

Verify the ADC identity (not the gcloud config) before blaming the
perimeter — they are separate credential stores:
```
curl -s "https://oauth2.googleapis.com/tokeninfo?access_token=$(gcloud auth application-default print-access-token)" | jq .email
```

### 1.5 Backlog — small TF edits, no prerequisites needed beyond data

- Populate `subsidiaries.kis.gemini_admin_members` /
  `gemini_end_user_members` once the real Workspace group addresses
  exist. (`module.iam_gemini` re-applies additively, 2 bindings.)
- Flip `var.enable_data_access_audit = true` to enable per-project
  `google_project_iam_audit_config` for `kis-gemini-enterprise` (Row 8
  partial). Watch log volume.
- Flip `var.lock_retention = true` in a dedicated sign-off MR
  (irreversible).
- Flip `failure_mode = "FAIL_CLOSED"` on the Model Armor binding after
  the Model Armor enforcement path is validated end-to-end.
- (Row 44 already wired; no further backlog item.)

---

## 2. Scenario matrix (Rows 2–49)

### Gemini Enterprise App (Rows 2–12)

| Row | Scenario | Status | Notes |
|---|---|---|---|
| 2 | 비인가 사용자 접근 | ✅ partial / 🔴 partial | **✅** `module.iam_gemini` applied (empty groups). **TF backlog:** populate `gemini_admin_members` / `gemini_end_user_members` when Workspace groups exist. **🔴 Org Policy** `iam.allowedPolicyMemberDomains` — Cloud Admin. |
| 3 | Prompt 민감 데이터 입력 | ✅ / 🟡 / ☐ | **✅** Model Armor template applied in `us` (SDP + PI/Jailbreak + RAI). **🟡** Wiring to GE engine declared via `google_discovery_engine_assistant.customer_policy.model_armor_config.user_prompt_template` — needs one-off `terraform import` then `apply` (GE auto-creates `default_assistant`). **☐ SecOps:** 보안교육 LMS 모듈 등재; flip `failure_mode = "FAIL_CLOSED"` after the integration is validated. |
| 4 | Gemini 응답 민감 데이터 노출 | ✅ / 🟡 / ☐ | **✅** DLP de-identify + inspect templates applied in `us` (6 KOREA_* + 5 universal info types). Model Armor template doubles as response sanitizer (same template currently for both directions). **🟡** Same import-then-apply step as Row 3 to activate the binding. **☐ SecOps:** Grounding datastore 인덱싱 거버넌스 Runbook; split into prompt-only vs response-only Model Armor templates later for tighter policies. |
| 5 | Prompt Injection / Jailbreak | ✅ | Folded into Row 3 Model Armor template's `pi_and_jailbreak_filter_settings`. |
| 6 | 외부망 / 비관리 디바이스 접근 | 🔴 + ☐ | **🔴** Access Context Manager Access Level — needs org-level Access Policy. **☐ Finance:** Chrome Enterprise Premium 라이선스. **☐ Workspace:** BeyondCorp Console에서 Device posture 정책. |
| 7 | VPC-SC: 외부 서비스 데이터 유출 | ✅ (ENFORCED) | Live in enforce mode (`enable_vpc_sc = true`, `vpc_sc_dry_run = false`) since 2026-05-22. Violations are **blocked**, not just logged. **Restricts 5 services**: aiplatform + storage + bigquery + dlp + cloudkms. `discoveryengine.googleapis.com` is **explicitly excluded** so Gemini Enterprise end-users hitting the LB at `kis-gemini.koreainvestment.com` (not in the corporate access level) are not blocked — see §1.4a. Single ingress rule admits `snswang@mz.co.kr` from any source. Operating contract: pin human Console/CLI quota project to `kis-gemini-enterprise`. |
| 8 | Audit Log 비활성화 | ✅ partial / 🔴 partial | **✅** Project sink + bucket applied (covers `kis-gemini-enterprise` audit logs). To flow `DATA_READ`, flip `var.enable_data_access_audit = true` (creates `google_project_iam_audit_config`). **🔴** Org-wide aggregated sink + Org IAM Audit Config — Cloud Admin. **☐ Workspace:** `gcloud organizations enable-access-transparency`. |
| 9 | Quota / 사용량 남용 | ✅ | `google_service_usage_consumer_quota_override.discoveryengine_conversational_per_min` on `discoveryengine.googleapis.com/conversational_search_read_requests` (read path of the Assistant chat flow). Override pinned via `var.discoveryengine_conversational_qpm`; **platform allows only 0–600 on this metric** (overrides can only tighten the GCP default of 600). Default = 600 (explicit pin); lower for stricter abuse protection. The codebase's original `discoveryengine.googleapis.com/queries` metric doesn't exist; real metric IDs were discovered via `gcloud alpha services quota list`. |
| 10 | 필수 API 임의 비활성화 | 🔴 + ☐ | **🔴 Org Policy** `serviceuser.services` allow-list — Cloud Admin. **☐ SecOps:** PAM workflow for `roles/serviceusage.serviceUsageAdmin` JIT. |
| 11 | 3rd-party Connector 유출 | 🔴 + ☐ | **🔴** Org Firewall Policy — Cloud Admin + org VPC plan. **☐ SecOps:** Connector SA key rotation (Cloud Scheduler + Functions). |
| 12 | 허용 리전 외 자원 생성 | 🔴 | **🔴 Org Policy** `gcp.resourceLocations` (allow `in:asia-northeast3-locations`) — Cloud Admin. |

### BigQuery (Rows 13–20) — KMS keyring is ready, no BQ workloads yet

| Row | Scenario | Status | Notes |
|---|---|---|---|
| 13 | 데이터셋 권한 과다 부여 | 🟡 | Apply when BQ datasets + Workspace groups (`bq-readers@`, `bq-editors@`, `bq-users@`) exist. Use `terraform-google-modules/iam/google//modules/projects_iam` (same pattern as `iam_gemini`). |
| 14 | PII 미식별/미분류 | ✅ partial / 🟡 partial | **✅** Data Catalog `PII_TAXONOMY` + Policy Tags (`confidential`, `internal`) applied. Column tagging happens at BQ schema-create time. **🟡 BQ DLP Discovery Config** deferred — paid scan feature, no BQ tables yet. |
| 15 | Authorized View/Dataset 미사용 | 🟡 | Pattern only; concrete `google_bigquery_dataset_access` resources added per dataset. |
| 16 | 대량 Export / Exfiltration | ✅ (ENFORCED) | Covered by the same enforced perimeter as Rows 7/26 — `bigquery.googleapis.com` in `var.vpc_sc_restricted_services`. Bulk BQ export from outside the access level / outside the perimeter is **denied** by the perimeter. |
| 17 | Row/Column Level Access | 🟡 | Policy Tag taxonomy is ready (Row 14). Concrete column-tag bindings + `google_bigquery_row_access_policy` are per-table. |
| 18 | CMEK 미적용 | ✅ partial / 🔴 partial | **✅** KMS keyring + `bq-cmek` key created in `kis-gemini-enterprise`. **🔴 Org Policy** `gcp.restrictNonCmekServices` to *force* CMEK — Cloud Admin. Per-dataset `default_encryption_configuration` is per-table. |
| 19 | Quota/Cost 폭증 | 🚫 | BQ `ENTERPRISE` Reservation costs real money; deferred until BQ usage exists. Custom `maximum_bytes_billed` is BI-tool-side. |
| 20 | BQ Data Access Audit Log 비활성 | 🔴 | Org-level `google_organization_iam_audit_config` for bigquery.googleapis.com — Cloud Admin. |

### Cloud Storage (Rows 21–28)

| Row | Scenario | Status | Notes |
|---|---|---|---|
| 21 | 버킷 Public 노출 | ✅ partial / 🔴 partial | **✅** Audit bucket has `public_access_prevention = "enforced"`. **🔴 Org Policy** `storage.publicAccessPrevention` to enforce on every bucket — Cloud Admin. |
| 22 | UBLA 미적용 | ✅ partial / 🔴 partial | **✅** Audit bucket has UBLA enabled. **🔴 Org Policy** `storage.uniformBucketLevelAccess` — Cloud Admin. |
| 23 | GCS PII 분류 미수행 | 🟡 | GCS DLP Discovery Config deferred — paid scan feature, only audit bucket to scan (which would be a privacy faux pas anyway). Reuses `google_data_loss_prevention_inspect_template.ge_inspect`. |
| 24 | 버전 관리 / Retention 미설정 | ✅ partial / 🟡 partial | **✅** Audit bucket has versioning + 2,555d retention (unlocked). **🟡** Same template applies to future GCS workload buckets — adopt the codebase's `kr_secure_bucket_template` resource when those buckets are created (incl. CMEK via `module.kms_data_keyring.keys["gcs-cmek"]`). |
| 25 | CMEK 미적용 | ✅ partial / 🔴 partial | **✅** KMS `gcs-cmek` key created. **🔴 Org Policy** `gcp.restrictNonCmekServices` — Cloud Admin. Per-bucket `encryption.default_kms_key_name` is per-bucket. |
| 26 | VPC-SC Perimeter 우회 | ✅ (ENFORCED) | Same enforced perimeter as Rows 7/16. `storage.googleapis.com` + access level cover the GCS-bypass vector — GCS calls into perimeter projects from outside the access level are **denied**. |
| 27 | IAM Conditions 미사용 | 🟡 | Pattern in codebase; project-level. Apply per concrete use case (e.g., time-bound `internal-readers@` group access). |
| 28 | GCS Data Access Audit Log 비활성 | 🔴 | Org-level `google_organization_iam_audit_config` for storage.googleapis.com — Cloud Admin. |

### Cloud Identity (Rows 29–38) — needs `workspace_customer_id` from Workspace Admin

| Row | Scenario | Status | Notes |
|---|---|---|---|
| 29 | 2단계 인증(MFA) | 🔴 + ☐ | TF group needs `workspace_customer_id`. **☐ Workspace:** 2-Step Verification Enforcement ON / Security Key Only. |
| 30 | Admin Advanced Protection | 🔴 + ☐ | TF group needs `workspace_customer_id`. **☐ SecOps:** APP self-enrollment 안내 + 분기 점검. |
| 31 | 의심스러운 로그인 | 🔴 | Access Context Manager Access Level — Cloud Admin Access Policy. |
| 32 | OAuth 앱 무단 승인 | ☐ | **☐ Workspace:** Admin Console → Security → API Controls → Restricted scopes (`cloud-platform`, `iam`, `aiplatform`), App Access Control = "Trusted apps only". |
| 33 | 외부 멤버 차단 | 🔴 + ☐ | Folded into Row 2 Org Policy. **☐ Workspace:** Group settings `Allow members from outside this organization` = OFF. |
| 34 | SA Key 노출/장기 미회전 | 🔴 | **🔴 Org Policy** `iam.disableServiceAccountKey*` — Cloud Admin. |
| 35 | 비활성/퇴사자 계정 | ☐ + ☐ | **☐ Workspace:** Auto-suspend 90d. **☐ SecOps:** Recommender 자동 회수 자동화. |
| 36 | Access Approval 미설정 | 🔴 | `google_organization_access_approval_settings` — Cloud Admin. |
| 37 | Cloud Shell 차단 | ☐ + ☐ | **☐ Workspace:** Cloud Shell = OFF for everyone. **☐ Alternative:** Cloud Workstations 별도 배포. |
| 38 | 민감 자원 Data Access Log 비활성 | 🔴 | Org-level audit configs for discoveryengine + aiplatform + iam — Cloud Admin. |

### Agent Engine (Rows 39–45) — single-project = `kis-gemini-enterprise`; no agent workloads deployed yet

| Row | Scenario | Status | Notes |
|---|---|---|---|
| 39 | Agent SA 과대 권한 | 🟡 | Apply when agent SAs exist; conditional IAM with `safe_*` dataset prefix is project-local. |
| 40 | Function Calling Tool 악용 | ☐ | **☐ Code:** Agent input schema validation; CI verification. |
| 41 | Agent Prompt / Code Tampering | 🟡 | Binary Authorization — **would block ALL unattested container deploys on the project**. Apply only after a CI/CD attestor pipeline exists. |
| 42 | Agent External API/Tool 무단 호출 | 🔴 | Org Firewall Policy — Cloud Admin. |
| 43 | Agent 응답 민감 데이터 노출 | ✅ | Reuses Row 3/4 Model Armor + DLP templates (already applied). |
| 44 | Agent 무한 추론 | ✅ | `google_service_usage_consumer_quota_override.reasoning_engine_query_per_min` on `aiplatform.googleapis.com/reasoning_engine_service_query_requests` (Vertex AI Reasoning Engine query path; regional, scoped to `var.region_primary`). Override pinned via `var.reasoning_engine_query_qpm` (default 90 = platform default, range 0–90 — tighten-only). Forward-ready: catches abuse the moment an Agent workload is deployed in this project. The codebase's original `online_prediction_requests` + `/min/project` metric ID was wrong; real metric discovered via `gcloud alpha services quota list`. |
| 45 | Agent SA Impersonation 남용 | 🟡 | Apply when agent SAs + agent-operators group exist. WIF declared out of scope; the codebase's `google_iam_workload_identity_pool` is **skipped**. |

### SCC Premium/Enterprise (Rows 46–49) — 🚫 OUT OF SCOPE THIS PHASE

| Row | Scenario | Status |
|---|---|---|
| 46 | IAM 이상 행위 (ETD) | 🚫 |
| 47 | Attack Path 미식별 | 🚫 |
| 48 | PII/금융정보 분류 누락 | 🚫 |
| 49 | 위협 인텔리전스 미연동 | 🚫 |

Revisit when SCC Premium tier is purchased.

---

## 3. Next steps grouped by owner

### 3.1 IaC team — concrete tfvars changes, no permissions needed

- [ ] **Populate Workspace groups (Row 2 backlog)**: set `subsidiaries.kis.gemini_admin_members` and `gemini_end_user_members` in `terraform.tfvars` once the real Workspace group addresses are known. Re-apply (2 additive IAM bindings via `module.iam_gemini`).
- [ ] **Flip `var.enable_data_access_audit = true`** (Row 8): creates `google_project_iam_audit_config` per subsidiary; routes `DATA_READ`/`DATA_WRITE` audit logs through the existing sink. Watch log volume cost.
- ~~Re-add Vertex AI quota override (Row 44)~~ — done. Row 44 wired via `google_service_usage_consumer_quota_override.reasoning_engine_query_per_min` on `aiplatform.googleapis.com/reasoning_engine_service_query_requests` (regional).

### 3.2 IaC team — code work when prerequisites materialize

- [ ] **Row 14 — BQ DLP Discovery Config**: lift `google_data_loss_prevention_discovery_config.bq_discovery` from `codebase/tf/modules/bigquery.tf` (reuse `google_data_loss_prevention_inspect_template.ge_inspect`) once BQ tables exist. **Cost note:** DLP Discovery is metered per resource scanned.
- [ ] **Row 23 — GCS DLP Discovery Config**: same pattern for GCS once non-audit buckets exist.
- [ ] **Row 24 — Secure GCS bucket template**: when workload GCS buckets are created, follow `codebase/tf/modules/cloud_storage.tf` `kr_secure_bucket_template` (versioning + retention + CMEK via `module.kms_data_keyring.keys["gcs-cmek"]`).
- [ ] **Row 13 — BQ IAM module**: when BQ datasets exist + Workspace groups exist, add `terraform-google-modules/iam/google//modules/projects_iam` with bq-readers / bq-editors / bq-users bindings.
- [ ] **Row 39/45 — Agent IAM**: when agent SAs exist, add conditional IAM bindings.

### 3.3 Cloud Admin — needs sign-off on org `240369219899`

These are all blocked until cloud-admin team applies them, and ideally
in a dedicated MR with explicit approval (each one has org-wide blast
radius).

- [ ] **Grant `roles/accesscontextmanager.policyAdmin`** on org `240369219899` to the Terraform applier (`snswang@mz.co.kr`). Unblocks Rows 6, 7, 16, 26, 31 — Terraform then creates the Access Policy + Access Level + Service Perimeter on the next apply (`vpc-sc.tf`, `var.enable_vpc_sc = true`).
- [ ] **Org Policies:**
  - `iam.allowedPolicyMemberDomains` (Row 2 / 33)
  - `serviceuser.services` allow-list (Row 10)
  - `gcp.resourceLocations` (Row 12)
  - `gcp.restrictNonCmekServices` (Row 18 / 25) — only after CMEK is rolled into BQ/GCS workloads
  - `storage.publicAccessPrevention` (Row 21)
  - `storage.uniformBucketLevelAccess` (Row 22)
  - `iam.disableServiceAccountKeyCreation` + `iam.disableServiceAccountKeyUpload` (Row 34)
- [ ] **Org IAM Audit Config** for discoveryengine, aiplatform, bigquery, storage, iam (Rows 8, 20, 28, 38).
- [ ] **Org Aggregated Sink** (Row 8) — if a centralized log destination is wanted (we currently keep audit logs in each subsidiary's project).
- [ ] **Org Access Approval** (Row 36).
- [ ] **Org Firewall Policies** (Rows 11, 42) — when the org VPC plan is finalized.
- [ ] **`gcloud organizations enable-access-transparency`** (Row 8).

### 3.4 Workspace Admin (`koreainvestment.com` tenant)

- [ ] **Provide `workspace_customer_id`** (`C0...`) to the IaC team for Rows 29 / 30 / 33.
- [ ] **Provide Workspace group addresses** for `gemini_admin_members` and `gemini_end_user_members` (Row 2 backlog).
- [ ] **Console settings** (no TF):
  - 2-Step Verification Enforcement ON (Row 29)
  - APP self-enrollment guidance for admin group (Row 30)
  - API Controls → Restricted scopes (Row 32)
  - Group settings: `Allow external members` = OFF (Row 33)
  - User Lifecycle: Auto-suspend 90d (Row 35)
  - Additional Google services → Cloud Shell = OFF (Row 37)

### 3.5 Finance + SecOps — paid features

- [ ] **Chrome Enterprise Premium** (Row 6) — required for Device posture (Endpoint Verification).
- [ ] **DLP Discovery scanning** (Rows 14, 23) — metered per scan; budget approval before turning it on once BQ/GCS workloads exist.
- [ ] *(Deferred)* SCC Premium tier (Rows 46–49).

### 3.6 SecOps — operational runbooks (no TF)

- [ ] **Row 3**: 보안교육 LMS module + 분기 캠페인.
- [ ] **Row 4**: Discovery Engine 인덱싱 거버넌스 Runbook + Cloud Workflows DLP-scan step.
- [ ] **App-side integration**: wire the Model Armor + DLP templates into the GE app / Agent response path (currently the templates are defined artifacts, not active enforcement).
- [ ] **Row 10**: PAM workflow for JIT `roles/serviceusage.serviceUsageAdmin`.
- [ ] **Row 11**: Connector SA key rotation automation (Cloud Scheduler + Cloud Functions).
- [ ] **Row 19**: BI-tool `maximum_bytes_billed` 강제 + BQ Admin 코드 검수.
- [ ] **Row 35**: Recommender 자동 회수 스크립트.
- [ ] **Row 40**: Agent input schema validation + CI step.

---

## 4. Console-side next steps for `kis-gemini-enterprise`

These are immediate follow-up actions in the **GCP Console** after the
current TF apply:

1. **GE app smoke test** — `https://console.cloud.google.com/gen-app-builder?project=kis-gemini-enterprise` → click `ge-engine-29118f` → confirm it's an **Intranet** app.
2. **Audit log verification** — trigger a sample event (`gcloud iam roles list --project=kis-gemini-enterprise`) and confirm a JSON line lands in `gs://kis-gemini-enterprise-audit-logs/cloudaudit.googleapis.com/...` within a few minutes.
3. **LB cert ACTIVE** — once DNS A record `kis-gemini.koreainvestment.com → <lb_ip>` is published, watch `gcloud compute ssl-certificates describe <cert>` until status = `ACTIVE` (~30 min).
4. **`gemini_app_id` verification** — open the GE engine → Integration tab → confirm the path-segment after `/home/cid/` matches the value in tfvars. If not, update tfvars and re-apply.
5. **Model Armor template visibility** — `https://console.cloud.google.com/security/model-armor?project=kis-gemini-enterprise` → switch region to **`us` (multi-region)** → confirm `ge-user-prompt-sanitize` template exists. (Pinned to `us` because the embedded SDP filter calls DLP, which only resolves KR_* detectors in the us multi-region.)
5a. **Model Armor → GE assistant binding** — in the GE console (`https://console.cloud.google.com/gen-app-builder?project=kis-gemini-enterprise`) → click the engine → Configurations → confirm the assistant's safety/customer-policy section references the `ge-user-prompt-sanitize` template for both prompt and response paths. Smoke test: send a chat query containing a fake KR_RRN string and confirm it's masked.
6. **DLP templates** — Security → Sensitive Data Protection → switch location to **`us` (multi-region)** → Templates → confirm `GE Response De-identification` + `KR PII + Finance Inspect`. Same regional constraint as Model Armor.
7. **Data Catalog taxonomy** — Data Catalog → Policy Tag taxonomies → confirm `PII_TAXONOMY` with `confidential` + `internal` tags.
8. **Quota overrides** — APIs & Services → Quotas → filter `Conversational search read requests` → confirm `var.discoveryengine_conversational_qpm` (default 600) value is `Effective`. Then filter `Query Reasoning Engine requests` → confirm `var.reasoning_engine_query_qpm` (default 90) value is `Effective` for `var.region_primary`.
9. **KMS keyring** — Security → Key Management → `asia-northeast3` → confirm `kr-data-keyring` with keys `bq-cmek` + `gcs-cmek`. Granting Encrypter/Decrypter to workload SAs happens **when** workloads (BQ datasets, GCS buckets) start using CMEK.

---

## 5. Change log

| Date | Change | Owner |
|---|---|---|
| 2026-05-21 | Initial checklist after phase 1 apply | snswang@mz.co.kr |
| 2026-05-21 | Scope narrowed to single-project; SCC deferred; added Tier 1 security controls (Rows 3, 4, 9, 14 partial, 18/25 partial, 44) to `iac/envs/prd/security.tf` | snswang@mz.co.kr |
| 2026-05-21 | Removed Row 9 + Row 44 quota overrides from `security.tf` (codebase metric IDs returned `COMMON_QUOTA_LIMIT_NOT_FOUND`); marked them 🟡 deferred pending metric-ID discovery via `gcloud services quota list` | snswang@mz.co.kr |
| 2026-05-22 | Pinned DLP de-id + inspect templates and Model Armor template to `us` multi-region (KR_RRN/KR_DLN/KR_PASSPORT detectors not available in asia-northeast3). KMS + Data Catalog stay in asia-northeast3. Added `local.security_templates_location` constant in `security.tf` | snswang@mz.co.kr |
| 2026-05-22 | Added `var.billing_project` + set `billing_project = var.billing_project` on both google providers — DLP/Model Armor resources only carry `parent` (no `project` arg), so `user_project_override = true` without explicit `billing_project` falls back to a default consumer project | snswang@mz.co.kr |
| 2026-05-22 | Corrected DLP info-type names: `KR_*` (non-existent) → `KOREA_*`. Added `KOREA_BRN` / `KOREA_ARN` / `KOREA_NHI_NUMBER` (finance-relevant, validated via `GET /v2/locations/us/infoTypes`) | snswang@mz.co.kr |
| 2026-05-22 | Wired Model Armor template to the GE engine via `google_discovery_engine_assistant.customer_policy.model_armor_config` (Rows 3 + 4 now actually enforce). `failure_mode = "FAIL_OPEN"` for initial rollout; `web_grounding_type = "WEB_GROUNDING_TYPE_DISABLED"` | snswang@mz.co.kr |
| 2026-05-22 | Onboarding gotcha: GE auto-creates `default_assistant` per engine, so `terraform import` (one CLI per subsidiary) is required before the first `apply` of the assistant resource. Documented in onboarding flow. Upgrade to TF ≥ 1.7 enables a declarative `for_each` import block. | snswang@mz.co.kr |
| 2026-05-22 | Restructured §1 to per-resource status (✅ applied / 🟡 apply pending / 🟦 operator follow-up). All security templates (Model Armor, DLP, KMS, Data Catalog) now ✅ applied after the KOREA_* + `us` region + `billing_project` fixes. Outstanding items: `terraform import` the GE Assistant, DNS publication for the LB managed cert. | snswang@mz.co.kr |
| 2026-05-22 | Row 9 implemented: `google_service_usage_consumer_quota_override` on `discoveryengine.googleapis.com/conversational_search_read_requests` (`/min/{project}`), tunable via `var.discoveryengine_conversational_qpm` (default 1000). Real metric ID discovered via `gcloud alpha services quota list`. | snswang@mz.co.kr |
| 2026-05-22 | Row 9 fix: platform caps consumer overrides on this metric at **600/min** (tighten-only). Changed `var.discoveryengine_conversational_qpm` default 1000 → 600 + added 0–600 validation. | snswang@mz.co.kr |
| 2026-05-22 | Row 44 implemented: `google_service_usage_consumer_quota_override` on `aiplatform.googleapis.com/reasoning_engine_service_query_requests` (`/min/{project}/{region}`, regional via `dimensions = { region = var.region_primary }`), tunable via `var.reasoning_engine_query_qpm` (default 90, 0–90 validation per Row 9 tighten-only pattern). Forward-ready for when an Agent workload is deployed. Real metric ID discovered via `gcloud alpha services quota list`. | snswang@mz.co.kr |
| 2026-05-22 | Rows 7 / 16 / 26 code-ready: `iac/envs/prd/vpc-sc.tf` adds Access Policy + Access Level + Service Perimeter (DRY_RUN by default, members + IP allowlists, prevent_destroy). All gated on `var.enable_vpc_sc = false` so apply doesn't trip on the `policyAdmin` permission gap (`snswang@mz.co.kr` currently lacks it). `accesscontextmanager.googleapis.com` added to managed APIs. New runbook in §1.4a. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC enforce-mode attempt: applied with `vpc_sc_dry_run = false`. Terraform state reads + BigQuery Console blocked with `SecurityPolicyViolated` even with snswang in access level + ingress policy (`identities=[user:snswang@mz.co.kr]`, `sources.accessLevel="*"`, all 6 services, resources=["*"]). Rolled back to DRY_RUN. **Open debug:** triage 3 captured `vpcServiceControlsUniqueIdentifier`s via Logs Explorer to understand the access-level matching gap. **Operational gotcha:** Terraform billing-project attribution forwards otherwise-outside calls into the perimeter — workaround = `gcloud auth application-default set-quota-project kis-common-gcp` for state ops. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC root cause identified via Logs Explorer: `violationReason = RESOURCES_NOT_IN_SAME_SERVICE_PERIMETER` — cross-perimeter project crossing (quota project outside, target inside). `access_level = "*"` only admits identity-context sources, not project-context. Added `var.vpc_sc_ingress_source_projects` + dynamic ingress block to bridge via `sources.resource = "projects/<NUMBER>"`. Discovered GCP constraint: `access_level = "*"` cannot coexist with `sources.resource` in the same `ingress_from` — split into two `ingress_policies` blocks. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC: dropped the cross-project bridge (Rule B). Operating contract instead: human Console/CLI sessions pin browser quota project to `kis-gemini-enterprise`; Terraform retains the dual-credential setup (ADC quota = kis-common-gcp for state ops; provider `billing_project = kis-gemini-enterprise`). `var.vpc_sc_ingress_source_projects = []` in tfvars; variable + dynamic block preserved in code for one-line re-enable. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC: removed `discoveryengine.googleapis.com` from `var.vpc_sc_restricted_services`. Rationale: Gemini Enterprise end-users hit the global LB at `kis-gemini.koreainvestment.com` and are NOT in the corporate access level; restricting discoveryengine would block legitimate end-user serving traffic in enforce mode. 5 services remain restricted: aiplatform, storage, bigquery, dlp, cloudkms. Discovery Engine remains governed by IAM + Row 9 quota override. | snswang@mz.co.kr |
| 2026-05-22 | VPC-SC flipped to ENFORCE (`vpc_sc_dry_run = false`). Rows 7 / 16 / 26 now ✅ (ENFORCED). Violations against the 5 restricted services from outside the access level / outside the perimeter are blocked, not just logged. Diagnosis rules + operating contract documented in §1.4a; stale "don't flip" guard in `terraform.tfvars` replaced with the resolved-state comment. | snswang@mz.co.kr | snswang@mz.co.kr |
